import json
import numpy as np
import random

data = {}
data["Problemas"] = []
expertos ={}
contador = 0
#Para los problemas
for i in range(0, int(150)):
    # Para el numero de expertos y alternativas
    for j in range(5,7):
        num_alternativas = j
        num_valores = ( (num_alternativas * num_alternativas) - num_alternativas )
        expertos["expertos"] = []

        # Genero los expertos
        for l in range(0,4):
            # Vector de criterios
            pesos_criterios = np.ones(j)
            
            # Genero su opinión
            valores = []
            for k in range(0, num_valores):
                numero = str(random.random())[0:4]
                valores.append(float(numero))
            # A expertos, le añado su nuevo experto
            expertos["expertos"].append({
                "pesoProblema": 1, 
                "pesoCriterios": pesos_criterios.tolist(), 
                "opinion": valores, 
                "nombre": str(random.randint(0,j))})
        # Una vez que se han creado los expertos, lo añado al problema
        data["Problemas"].append({"nombre": str(contador), 
            "expertos":expertos["expertos"], 
            "numCriterios": 1,
            "numAlternativas": num_alternativas})

        contador = contador + 1

    with open("gndd_5_6_alternativas_4_expertos.json", "w") as file:
        json.dump(data, file, indent=4)