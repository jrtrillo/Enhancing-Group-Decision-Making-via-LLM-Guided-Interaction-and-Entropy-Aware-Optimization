package Vista;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;import java.nio.file.Path;

import java.nio.file.Files;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class MistralJavaClient {
    // El modelo que estás sirviendo en tu contenedor Docker de TGI
    private static final String MODEL_ID = "mistralai/Mistral-7B-Instruct-v0.1";
    // Endpoint local de Text-Generation-Inference en Docker
    private static final String API_URL = "http://localhost:8080/v1/models/mistral/infer";
    private static final ObjectMapper MAPPER = new ObjectMapper();

    public static void main(String[] args) throws IOException, InterruptedException {
        System.out.println("Leyendo preferencias...");
        // Ajusta esta ruta a donde tengas tu preferences.txt
        String preferencesPath = "C:\\Users\\quesa\\Desktop\\UGR\\proyectoSalerno\\preferences.txt";
        String preferences = Files.readString(Path.of(preferencesPath)).trim();
        if (preferences.isEmpty()) {
            System.out.println("Warning: preferences.txt está vacío");
        }

        String prompt = buildPrompt(preferences);
        System.out.println("Prompt:\n" + prompt);

        String response = callTgiLocal(prompt);
        System.out.println("\n=== Respuesta de Mistral (TGI local) ===\n" + response);
    }

    private static String buildPrompt(String preferences) {
        return String.join("\n",
                "You are an AI that analyzes expert preferences.",
                "Given the following pairwise comparisons from different experts, determine which alternative is the best overall and which expert prefer that alternative:",
                "",
                // Aquí concatenamos las preferencias leídas del archivo
                "IMPORTANT: You should note that users prefer an alternative if they have a 60% or more " + preferences,
                "",
                "Your answer must start with: 'The best alternative is Alternative X'",
                "Then provide a second sentence listing the experts who chose that alternative in this exact format:",
                "'The experts who decided on Alternative X are Expert Y and Expert Z.'"
        );
    }

    private static String callTgiLocal(String prompt) throws IOException, InterruptedException {
        // Construimos el payload según el formato que espera TGI
        ObjectNode payload = MAPPER.createObjectNode();
        payload.putArray("data").add(prompt);
        ObjectNode parameters = payload.putObject("parameters");
        parameters.put("max_new_tokens", 400);
        parameters.put("temperature", 0.7);
        parameters.put("top_p", 0.9);

        String requestBody = MAPPER.writeValueAsString(payload);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(API_URL))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                .build();

        System.out.println("Generando respuesta...");
        HttpResponse<String> httpResponse = HttpClient.newHttpClient()
                .send(request, HttpResponse.BodyHandlers.ofString());

        if (httpResponse.statusCode() != 200) {
            throw new IOException("Error en TGI local: HTTP "
                    + httpResponse.statusCode() + " - " + httpResponse.body());
        }

        JsonNode root = MAPPER.readTree(httpResponse.body());
        if (!root.has("generated_text")) {
            throw new IOException("Respuesta inesperada de TGI local: " + httpResponse.body());
        }
        return root.get("generated_text").asText();
    }
}
