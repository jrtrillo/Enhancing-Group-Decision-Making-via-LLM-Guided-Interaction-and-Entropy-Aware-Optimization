package Vista;
import java.io.IOException;
import java.util.Locale;
import java.util.ArrayList;
import java.util.Random;
import Algoritmo.Algoritmo;
import Modelo.Opinion;
import Modelo.Problema;
import Algoritmo.Enjambre;




public class Main {
	public Main() throws IOException {
	}

	public static float logBase2(float x) {
		return (float) (Math.log(x) / Math.log(2));
	}


	public static float obtenerEntropiaExperto(Opinion opinion){
		float entropia, auxiliar = 0;
		int division = opinion.getFilcolum() * opinion.getFilcolum() - opinion.getFilcolum();
		for(int i = 0; i < opinion.getFilcolum(); i++){
			for(int j = 0; j < opinion.getFilcolum(); j++){
				if(i!=j){
					float inverso = 1 - opinion.getOpinion()[i][j];
					if(inverso > 0 && inverso < 1){
//						System.out.println("INVERSO " + inverso);
//						System.out.println("Valor que se SUMA " + (opinion.getOpinion()[i][j]*logBase2(opinion.getOpinion()[i][j])) + " " + (inverso*logBase2(inverso)));
						auxiliar += (opinion.getOpinion()[i][j]*logBase2(opinion.getOpinion()[i][j])) + (inverso*logBase2(inverso));
//						System.out.println(auxiliar);
					}
					else{
//						System.out.println("INVERSO " + inverso);
//						System.out.println("Valor que se SUMA " + (opinion.getOpinion()[i][j]*logBase2(opinion.getOpinion()[i][j])) + " " + (inverso*logBase2(inverso)));
						auxiliar += 0;
//					System.out.println(auxiliar);
					}

				}
			}
//			System.out.println("AUXILIAR " + auxiliar);
		}
//		System.out.println("La entoripa es " + auxiliar + " y se divide por " + division);
		entropia = (auxiliar / division)*-1;
//		System.out.println("Entropia por experto " + entropia);
		return entropia;
	}


	public static double obtenerEntropiaProblema(Problema problema){
		double entropiaMedia = 0;

		for(int i = 0; i < problema.getNumExpertos(); i++){
			float entroExpert = obtenerEntropiaExperto(problema.getOpiniones().get(i).get(0));
			entropiaMedia+=entroExpert;
//			System.out.println("Entropiea Media " + entroExpert);
		}
		entropiaMedia = entropiaMedia / problema.getNumExpertos();
//		System.out.println("La entropia media es " + entropiaMedia);
		return entropiaMedia;
	}


	public static void main(String[] args) throws IOException {
		Random ran = new Random(2);
		double alpha = 0.2;
		double gamma = 0.5;
		int numIteracciones = 1800, pro = 26;

		Problema p = new Problema("opiniones/problemas.json", pro, alpha, gamma);
		double entropiaMedia = obtenerEntropiaProblema(p);
		Problema p_inicial_aux = new Problema("opiniones/problemas.json", pro, alpha, gamma);
		p.mostrarOpiniones();

		float consistenciaExperto = p.getConsistencia().nivelConsistenciaMatriz(p.getOpiniones().get(1).get(0).getOpinion());
		System.out.println("El nivel de consistencia de la matriz es " + consistenciaExperto);
		System.out.println(p.getConsenso().getNivelConsenso());
		float consensoASuperar = 0;
		int numAgentes = 10 * p.getCriterios() * p.getExpertos().size() * ((p.getAlternativas() * p.getAlternativas()) - p.getAlternativas());

		Algoritmo alg;
		Enjambre ad;
		Problema p_aux = new Problema("opiniones/problemas.json", pro, alpha, gamma);
		ArrayList<Float> evolucionConsenso = new ArrayList<>();



		int contadorRondas = 0;
//		while(consensoASuperar < 0.982 && contadorRondas < 30) {
////			System.out.println("La entropía vale " + entropiaMedia);
//
//			if(contadorRondas == 0) {
//				alg = new Algoritmo(numAgentes, numIteracciones, p, alpha, gamma, ran);
//				ad = alg.algoritmoPSOSalerno(ran, p.getConsistencia().getNivelConsistencia(), p.getConsenso().getNivelConsenso(), (float) entropiaMedia);
//			}
//			else{
//				alg = new Algoritmo(numAgentes, numIteracciones, p_inicial_aux, alpha, gamma, ran);
//				ad = alg.algoritmoPSOSalerno(ran, p.getConsistencia().getNivelConsistencia(), p.getConsenso().getNivelConsenso(), (float) entropiaMedia);
//			}
//
//
//
//
//			if (ad != null) {
//				ArrayList<Float> valoresOpiniones = new ArrayList<>();
//				for (int i = 0; i < ad.getVectorMejorPosicion().size(); i++) {
//					valoresOpiniones.add(ad.getVectorMejorPosicion().get(i));
//				}
//				int contador = 0;
//
//				for (int i = 0; i < p_aux.getNumExpertos(); i++) {
//					for (int j = 0; j < p_aux.getCriterios(); j++) {
//						for (int x = 0; x < p_aux.getAlternativas(); x++) {
//							for (int y = 0; y < p_aux.getAlternativas(); y++) {
//								if (x != y) {
//									float nuevoValor = valoresOpiniones.get(contador);
//									boolean acepta = true;
//									acepta = ran.nextDouble() < 0.5;
//
//
//
//									// Si no acepta, tomamos el valor original de p_inicial_aux
//									float valorFinal = acepta
//											? nuevoValor
//											: p_inicial_aux.getOpiniones().get(i).get(j).getOpinion()[x][y];
//
//									p_aux.setValorOpinion(i, j, x, y, valorFinal);
//									contador++;
//								}
//							}
//						}
//					}
//				}
//			}
//
//			p_aux.calcularConsistencia();
//			p_aux.calcularConsenso();
////			System.out.println("Consenso conseguido " + p_aux.getConsenso().getNivelConsenso() + " consenso inicial " + p_inicial_aux.getConsenso().getNivelConsenso() + " entropia conseguida " + entropiaMedia);
//			if(p_aux.getConsenso().getNivelConsenso() > p_inicial_aux.getConsenso().getNivelConsenso()){
////				p_aux.mostrarOpiniones();
//				System.out.println(p_aux.getConsenso().getNivelConsenso());
//
//				evolucionConsenso.add(p_aux.getConsenso().getNivelConsenso());
//
//				for (int i = 0; i < p.getNumExpertos(); i++) {
//					for (int j = 0; j < p.getCriterios(); j++) {
//						for (int x = 0; x < p.getAlternativas(); x++) {
//							for (int y = 0; y < p.getAlternativas(); y++) {
//								if (x != y) {
//									p_inicial_aux.getOpiniones().get(i).get(j).getOpinion()[x][y] = p_aux.getOpiniones().get(i).get(j).getOpinion()[x][y];
//								}
//							}
//						}
//					}
//				}
//				consensoASuperar = p_aux.getConsenso().getNivelConsenso();
//				p_inicial_aux.calcularConsistencia();
//				p_inicial_aux.calcularConsenso();
//			}
//			else{
//				System.out.println(p_inicial_aux.getConsenso().getNivelConsenso());
//			}
//			entropiaMedia = obtenerEntropiaProblema(p_inicial_aux);
////			p_inicial_aux.mostrarOpiniones();
//			contadorRondas++;
//		}

//		p_inicial_aux.mostrarOpiniones();
	}

}