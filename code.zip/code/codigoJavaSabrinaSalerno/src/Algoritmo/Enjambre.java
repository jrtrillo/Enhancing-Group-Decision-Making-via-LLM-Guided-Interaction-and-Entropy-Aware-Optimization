package Algoritmo;

import java.util.ArrayList;

public class Enjambre {
    private ArrayList<Particula> vectorParticulas;
    private ArrayList<Float> vectorMejorPosicion;
    private ArrayList<Float> mejorValoracionGlobal;
    private ArrayList<Float> valoresQs;

    Enjambre(){
        vectorParticulas = new ArrayList<>();
        vectorMejorPosicion  = new ArrayList<>();
        mejorValoracionGlobal = new ArrayList<Float>(3);
        valoresQs = new ArrayList<>(3);
    }

    Enjambre(ArrayList<Particula> particulas, float consistencia, float consenso, float gamma){
        vectorParticulas = particulas;
        vectorMejorPosicion = new ArrayList<>();
        for(int i = 0; i < particulas.get(0).getVectorPosicion().size(); i++){
            float aux = particulas.get(0).getVectorMejorPosicion().get(i);
            vectorMejorPosicion.add(aux);
        }

        //Cambiar según se quiera calcular
//        double q = gamma*consistencia + (1-gamma)*consenso;
//        double q = gamma*consistencia + (1-gamma)*consistencia;

//        double q = gamma*consenso + (1-gamma)*consenso;
        double q = consenso*consenso / (1+consenso);


        mejorValoracionGlobal = new ArrayList<>();
        mejorValoracionGlobal.add((float) q);
        mejorValoracionGlobal.add(consistencia);
        mejorValoracionGlobal.add(consenso);

        valoresQs = new ArrayList<>();
        valoresQs.add((float) q);
        valoresQs.add(consistencia);
        valoresQs.add(consenso);

    }

    Enjambre(ArrayList<Particula> particulas, float consistencia, float consenso, float entropia, float gamma){
        vectorParticulas = particulas;
        vectorMejorPosicion = new ArrayList<>();
        for(int i = 0; i < particulas.get(0).getVectorPosicion().size(); i++){
            float aux = particulas.get(0).getVectorMejorPosicion().get(i);
            vectorMejorPosicion.add(aux);
        }

        //Cambiar según se quiera calcular
//        System.out.println("Entrooia " + entropia);
//        double q = gamma*consistencia + (1-gamma)*consenso;
//        double q = gamma*consenso + (1-gamma)*consenso;
//        double q = gamma*consenso + (1-gamma)*(1-entropia);
//        double q = consenso*consenso / (1+(1-entropia));
//        double q = 0.5*consenso + (0.25)*(1-entropia) + (0.25)*consistencia;
        double q = (consenso*consenso * consistencia) / (1+(1-entropia));
//        double q = ((consenso*consenso*gamma) + (1-gamma)*consistencia) / (1+(1-entropia));
//        double q = 0.7*consenso + 0.3*(1-entropia);

        mejorValoracionGlobal = new ArrayList<>();
        mejorValoracionGlobal.add((float) q);
        mejorValoracionGlobal.add(consistencia);
        mejorValoracionGlobal.add(consenso);

        valoresQs = new ArrayList<>();
        valoresQs.add((float) q);
        valoresQs.add(consistencia);
        valoresQs.add(consenso);

    }

    public ArrayList<Float> getMejorValoracionGlobal() {
        return mejorValoracionGlobal;
    }

    public void setMejorValoracionGlobal(Float valor, int posicion) {
        this.mejorValoracionGlobal.set(posicion, valor);
    }

    public ArrayList<Float> getVectorMejorPosicion() {
        return vectorMejorPosicion;
    }

    public void setVectorMejorPosicion(Float valor, int posicion) {
        this.vectorMejorPosicion.set(posicion, valor);
    }

    public ArrayList<Float> getValoresQs() {
        return valoresQs;
    }

    public void setValoresQs(ArrayList<Float> valoresQs) {
        this.valoresQs = valoresQs;
    }
}
