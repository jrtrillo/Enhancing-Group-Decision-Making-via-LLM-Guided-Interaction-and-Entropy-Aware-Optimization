package Algoritmo;

import Modelo.Opinion;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Random;

public class Particula {
    private ArrayList<Float> vectorPosicion;
    private ArrayList<Float> vectorVelocidad;
    private ArrayList<Float> vectorMejorPosicion;
    private ArrayList<Float> mejoresValores;
    private int tamanio;

    Particula(){
        vectorPosicion = new ArrayList<>();
        vectorVelocidad = new ArrayList<>();
        vectorMejorPosicion = new ArrayList<>();
        mejoresValores = new ArrayList<>();
        tamanio = 0;
    }

//    public Particula(int numValores, Random ran, double alpha, ArrayList<Float> opinionesIniciales){
//        vectorPosicion = new ArrayList<>();
//        vectorVelocidad = new ArrayList<>();
//        vectorMejorPosicion = new ArrayList<>();
//        mejoresValores = new ArrayList<>();
//
//
//        for(int i = 0; i < numValores; i++){
//            float minimo = (float) (opinionesIniciales.get(i) - (alpha/2));
//            float maximo = (float) (opinionesIniciales.get(i) + (alpha/2));
//            double r = (ran.nextDouble()*(maximo-minimo) + minimo);
//            if(r > 1)
//                r=1;
//            if(r<0)
//                r=0;
//            vectorPosicion.add(Float.parseFloat(String.valueOf(r)));
//            vectorMejorPosicion.add(Float.parseFloat(String.valueOf(r)));
//            minimo = (float) -0.1;
//            maximo = (float) 0.1;
//            r = (ran.nextDouble() * (maximo-minimo) + minimo);
//            if(r > 0.1)
//                r=0.1;
//            if(r<-0.1)
//                r=-0.1;
//            vectorVelocidad.add(Float.parseFloat(String.valueOf(r)));
//        }
//
//        tamanio = numValores;
//
//        for(int i = 0; i < 3; i++){
//            mejoresValores.add((float) 0);
//        }
//    }

    public Particula(int numValores, Random ran, double alpha, ArrayList<Float> opinionesIniciales){
        vectorPosicion = new ArrayList<>();
        vectorVelocidad = new ArrayList<>();
        vectorMejorPosicion = new ArrayList<>();
        mejoresValores = new ArrayList<>();


        for(int i = 0; i < numValores; i++){
            vectorPosicion.add(opinionesIniciales.get(i));
            vectorMejorPosicion.add(opinionesIniciales.get(i));
            float minimo = (float) -0.1;
            float maximo = (float) 0.1;
            double r = (ran.nextDouble() * (maximo-minimo) + minimo);
            if(r > 0.1)
                r=0.1;
            if(r<-0.1)
                r=-0.1;
            vectorVelocidad.add(Float.parseFloat(String.valueOf(r)));
        }

        tamanio = numValores;

        for(int i = 0; i < 3; i++){
            mejoresValores.add((float) 0);
        }
    }

    public ArrayList<Float> getVectorPosicion() {
        return vectorPosicion;
    }

    public Float getMejorValor(int i) {
        return mejoresValores.get(i);
    }

    public ArrayList<Float> getMejoresValores() {
        return mejoresValores;
    }
    public void setValorVectorMejoresValores(float valor, int posicion){
        mejoresValores.set(posicion, valor);
    }
    public void setValorVectorMejorPosicion(float valor, int posicion){
        vectorMejorPosicion.set(posicion, valor);
    }
    public ArrayList<Float> getVectorMejorPosicion() {
        return vectorMejorPosicion;
    }

    public void setValorVectorVelocidad(int posicion, float valor){
        vectorVelocidad.set(posicion, valor);
    }

    public ArrayList<Float> getVectorVelocidad() {
        return vectorVelocidad;
    }

    public void setValorVectorPosicion(int posicion, float valor){
        vectorPosicion.set(posicion, valor);
    }

    public void setValorMejoresValores(int posicion, float valor){
        mejoresValores.set(posicion, valor);
    }
}
