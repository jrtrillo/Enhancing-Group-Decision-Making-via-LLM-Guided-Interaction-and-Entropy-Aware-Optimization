package Algoritmo;

import Modelo.Consenso;
import Modelo.Consistencia;
import Modelo.Opinion;
import Modelo.Problema;

import java.lang.ref.SoftReference;
import java.lang.reflect.Array;
import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Random;

public class Algoritmo {
    private ArrayList<Agente> agentes;
    private int numAgentes;
    private int numValores;
    private int numIte;
    private double alpha;
    private double gamma;
    private Problema p;

    private Consistencia consistenciaCalculada;
    private Consenso consensoCalculado;

    private ArrayList<Float> mejorasConsistencia;
    private ArrayList<Float> mejorasConsenso;
    private ArrayList<Float> criterioOptimizacion;

    public Algoritmo(){
        agentes = new ArrayList<>();
        numAgentes = 0;
        numIte = 0;
        alpha = 0;
        gamma = 0;

        consistenciaCalculada = new Consistencia();
        consensoCalculado = new Consenso();

        mejorasConsistencia = new ArrayList<>();
        mejorasConsenso = new ArrayList<>();
        criterioOptimizacion = new ArrayList<>();
    }

    public Algoritmo(int numAg, int numIteracciones, Problema _p, double _apl, double _gamm, Random ran){
        agentes = new ArrayList<>();
        numAgentes = numAg;
        numIte = numIteracciones;
        alpha = _apl;
        gamma = _gamm;
        Agente aux;

        int numExpertos = _p.getExpertos().size();
        int numAlternativas = _p.getAlternativas();
        int numCriterios = _p.getCriterios();

        ArrayList<Float> opinionesIniciales = this.convertirAAgente(_p.getOpiniones());

        numValores = numExpertos*(numCriterios*((numAlternativas*numAlternativas)-numAlternativas));

        for(int i = 0; i < numAgentes; i++){
            aux = new Agente(numValores, alpha, opinionesIniciales, ran);
            agentes.add(aux);
        }
        numValores = agentes.get(0).getTamanio();
        p = _p;

        consistenciaCalculada = new Consistencia();
        consensoCalculado = new Consenso();

        mejorasConsistencia = new ArrayList<>();
        mejorasConsenso = new ArrayList<>();
        criterioOptimizacion = new ArrayList<>();
    }

    public ArrayList<Float> convertirAAgente(ArrayList<ArrayList<Opinion>> opiIni){
        ArrayList<Float> matrizVector = new ArrayList<>();
        for(int i = 0; i < opiIni.size(); i++){
            for(int j = 0; j < opiIni.get(i).size(); j++){
                for(int x = 0; x < opiIni.get(i).get(j).getFilcolum(); x++){
                    for(int y = 0; y < opiIni.get(i).get(j).getFilcolum(); y++){
                        if(x!=y){
                            matrizVector.add(opiIni.get(i).get(j).getOpinion()[x][y]);
                        }
                    }
                }
            }
        }
        return matrizVector;
    }

    public Agente algoritmoEDBasico(Random ran){

        int NP = numAgentes;
        int numAgentesValidos = 0;
        int numAgentesInvalidos = 0;
        double valorASuperar = (gamma*p.getConsistencia().getNivelConsistencia()) + ((1-gamma)*p.getConsenso().getNivelConsenso());
//        double valorASuperar = p.getConsenso().getNivelConsenso();

        double CR = 0.2;
        double F = 0.8;
        Agente solucion = null;
        float nuevoConsenso;
        float nuevaConsistencia ;

        int numIteracciones = 0;
        while(numIteracciones < numIte){
            for(int i = 0; i < NP; i++){
                Agente agenteActual = this.copiarAgente(agentes.get(i));
                ArrayList<Integer> valores = escogerAgentes3(i, numAgentes - 1, ran);
                Agente a = agentes.get(valores.get(0));
                Agente b = agentes.get(valores.get(1));
                Agente c = agentes.get(valores.get(2));

                int R = (ran.nextInt()%numValores + 1);

                for(int j = 0; j < numValores; j++){
                    double r = ran.nextDouble()%1;
                    if(r < CR || j == R){
                        double yi = (a.getValor(j) + F*(b.getValor(j) - c.getValor(j)));

                        if(yi > 1){
                            yi = 1;
                        }
                        if(yi < 0){
                            yi = 0;
                        }
                        agenteActual.setValor(Float.parseFloat(String.valueOf(yi)), j);
                    }
                }
                // Función que comprueba el agente
//                 boolean agenteValido = obtenerDiferenciaGlobal(agenteActual);
                 boolean agenteValido = obtenerDiferenciaIndividual(agenteActual);
//                boolean agenteValido = obtenerDiferenciaUniforme(agenteActual);
                if(agenteValido){
                    numAgentesValidos += 1;

                    nuevoConsenso = this.calcularConsensoAgente(agenteActual.getVectorPesos());
                    nuevaConsistencia = this.calcularConsistenciaAgente(agenteActual.getVectorPesos());

                    double nuevoValor = (gamma*nuevaConsistencia) + ((1-gamma)*nuevoConsenso);
//                    double nuevoValor = nuevoConsenso;

                     if(nuevoValor > valorASuperar) {
                        solucion = copiarAgente(agenteActual);

                        this.criterioOptimizacion.add(Float.parseFloat(String.valueOf(nuevoValor).substring(0, 5)));

                        this.mejorasConsenso.add(Float.parseFloat(String.valueOf(nuevoConsenso).substring(0, 5)));
                        consensoCalculado.setNivelConsenso(Float.parseFloat(String.valueOf(nuevoConsenso).substring(0, 5)));

                        this.mejorasConsistencia.add(Float.parseFloat(String.valueOf(nuevaConsistencia).substring(0, 5)));
                        consistenciaCalculada.setNivelConsistencia(Float.parseFloat(String.valueOf(nuevaConsistencia).substring(0, 5)));

                        valorASuperar = nuevoValor;

                        for(int s = 0; s < agenteActual.getTamanio(); s++){
                            agentes.get(i).setValor(agenteActual.getValor(s), s);
                        }
                    }
                }
                else {
                    numAgentesInvalidos += 1;
                }
            }
            numIteracciones++;
        }
        System.out.println("CRiterio de optimización");
        for(int i = 0; i < criterioOptimizacion.size(); i++){
            System.out.print(criterioOptimizacion.get(i) + " ");
        }
        System.out.println();
        System.out.println("Evolución F1");
        for(int i = 0; i < mejorasConsistencia.size(); i++){
            System.out.print(mejorasConsistencia.get(i) + " ");
        }
        System.out.println();
        System.out.println("Evolución F2");
        for(int i = 0; i < mejorasConsenso.size(); i++){
            System.out.print(mejorasConsenso.get(i) + " ");
        }

        System.out.println();
        System.out.println();

        System.out.println("Total de agentes válidos " + numAgentesValidos);
        System.out.println("Total de agentes inválidos " + numAgentesInvalidos);

        return solucion;
    }


    public Agente algoritmoEDBasicoCambioPoblacion(Random ran){

        int NP = numAgentes;
        int numAgentesValidos = 0;
        int numAgentesInvalidos = 0;

        ArrayList<Agente> poblacionActualizadaAuxiliar = new ArrayList<>();

        double valorASuperar = (gamma*p.getConsistencia().getNivelConsistencia()) + ((1-gamma)*p.getConsenso().getNivelConsenso());
//        double valorASuperar = p.getConsenso().getNivelConsenso();
        double CR = 0.1;
        double F = 0.9;
        Agente solucion = null;
        float nuevoConsenso;
        float nuevaConsistencia;

        int numIteracciones = 0;
        while(numIteracciones < numIte){
            for(int i = 0; i < NP; i++){
                Agente agenteActual = this.copiarAgente(agentes.get(i));
                ArrayList<Integer> valores = escogerAgentes3(i, numAgentes - 1, ran);
                Agente a = agentes.get(valores.get(0));
                Agente b = agentes.get(valores.get(1));
                Agente c = agentes.get(valores.get(2));

                int R = (ran.nextInt()%numValores + 1);

                for(int j = 0; j < numValores; j++){
                    double r = ran.nextDouble()%1;
                    if(r < CR || j == R){
                        double yi = (a.getValor(j) + F*(b.getValor(j)-c.getValor(j)));

                        if(yi > 1){
                            yi = 1;
                        }
                        if(yi < 0){
                            yi = 0;
                        }
                        agenteActual.setValor(Float.parseFloat(String.valueOf(yi)), j);
                    }
                }
                // Función que comprueba el agente
//                boolean agenteValido = obtenerDiferenciaGlobal(agenteActual);
                boolean agenteValido = obtenerDiferenciaIndividual(agenteActual);
                if(agenteValido){
                    numAgentesValidos += 1;
                    nuevoConsenso = this.calcularConsensoAgente(agenteActual.getVectorPesos());
                    nuevaConsistencia = this.calcularConsistenciaAgente(agenteActual.getVectorPesos());
                    double nuevoValor = (gamma*nuevaConsistencia) + ((1-gamma)*nuevoConsenso);
//                    double nuevoValor = nuevoConsenso;

                    if(nuevoValor > valorASuperar) {
                        solucion = copiarAgente(agenteActual);
                        this.criterioOptimizacion.add(Float.parseFloat(String.valueOf(nuevoValor).substring(0, 5)));

                        this.mejorasConsenso.add(Float.parseFloat(String.valueOf(nuevoConsenso).substring(0, 5)));
                        consensoCalculado.setNivelConsenso(Float.parseFloat(String.valueOf(nuevoConsenso).substring(0, 5)));

                        this.mejorasConsistencia.add(Float.parseFloat(String.valueOf(nuevaConsistencia).substring(0, 5)));
                        consistenciaCalculada.setNivelConsistencia(Float.parseFloat(String.valueOf(nuevaConsistencia).substring(0, 5)));

                        valorASuperar = nuevoValor;
//                        for(int s = 0; s < agenteActual.getTamanio(); s++){
//                            agentes.get(i).setValor(agenteActual.getValor(s), s);
//                        }
                        poblacionActualizadaAuxiliar.add(agenteActual);
                    }
                    poblacionActualizadaAuxiliar.add(agentes.get(i));
                }
                else {
                    numAgentesInvalidos += 1;
                    poblacionActualizadaAuxiliar.add(agentes.get(i));
                }
            }

            for(int k = 0; k < agentes.size(); k++){
                agentes.set(k, poblacionActualizadaAuxiliar.get(k));
            }

            poblacionActualizadaAuxiliar = new ArrayList<>();
            numIteracciones++;
        }
        System.out.println("Total de agentes válidos " + numAgentesValidos);
        System.out.println("Total de agentes inválidos " + numAgentesInvalidos);

        return solucion;
    }


    public Agente algoritmoEDBest2(Random ran){
        int NP = numAgentes;
        int numAgentesValidos = 0;
        int numAgentesInvalidos = 0;

        double valorASuperar = (gamma*p.getConsistencia().getNivelConsistencia()) + ((1-gamma)*p.getConsenso().getNivelConsenso());
//        double valorASuperar = p.getConsenso().getNivelConsenso();
        double CR = 0.6;
        double F = 0.9;
        Agente solucion = null;
        float nuevoConsenso = 0;
        float nuevaConsistencia = 0;

        int numIteracciones = 0;
        while(numIteracciones < numIte){
            for(int i = 0; i < NP; i++){
                Agente agenteActual = this.copiarAgente(agentes.get(i));
                ArrayList<Integer> valores = escogerAgentes4(i, numAgentes - 1, ran);

                Agente a = agentes.get(valores.get(0));
                Agente b = agentes.get(valores.get(1));
                Agente c = agentes.get(valores.get(2));
                Agente d = agentes.get(valores.get(3));

                int R = ran.nextInt()%numValores + 1;

                for(int j = 0; j < numValores; j++){
                    double r = ran.nextDouble()%1;
                    if(r < CR || j == R){
                        double yi = agenteActual.getValor(j) + F * (a.getValor(j) - b.getValor(j)) + F * (c.getValor(j) - d.getValor(j));
//                        System.out.println("El valor de YI es " + yi);

                        if(yi > 1){
                            yi = 1;
                        }
                        if(yi < 0){
                            yi = 0;
                        }
                        agenteActual.setValor(Float.parseFloat(String.valueOf(yi)), j);
                    }
                }
                // Función que comprueba el agente
//                boolean agenteValido = obtenerDiferenciaGlobal(agenteActual);
                 boolean agenteValido = obtenerDiferenciaIndividual(agenteActual);
                if(agenteValido){
                    numAgentesValidos += 1;
                    nuevoConsenso = this.calcularConsensoAgente(agenteActual.getVectorPesos());
                    nuevaConsistencia = this.calcularConsistenciaAgente(agenteActual.getVectorPesos());
                     double nuevoValor = (gamma*nuevaConsistencia) + ((1-gamma)*nuevoConsenso);
//                    double nuevoValor = nuevoConsenso;

                    if(nuevoValor > valorASuperar) {
                        solucion = copiarAgente(agenteActual);
                        this.criterioOptimizacion.add(Float.parseFloat(String.valueOf(nuevoValor).substring(0, 5)));

                        this.mejorasConsenso.add(Float.parseFloat(String.valueOf(nuevoConsenso).substring(0, 5)));
                        consensoCalculado.setNivelConsenso(Float.parseFloat(String.valueOf(nuevoConsenso).substring(0, 5)));

                        this.mejorasConsistencia.add(Float.parseFloat(String.valueOf(nuevaConsistencia).substring(0, 5)));
                        consistenciaCalculada.setNivelConsistencia(Float.parseFloat(String.valueOf(nuevaConsistencia).substring(0, 5)));

                        valorASuperar = nuevoValor;
                        for(int s = 0; s < agenteActual.getTamanio(); s++){
                            agentes.get(i).setValor(agenteActual.getValor(s), s);
                        }
                    }
                }
                else{
                    numAgentesInvalidos += 1;
                }
            }
            numIteracciones++;
        }
        System.out.println("Total de agentes válidos " + numAgentesValidos);
        System.out.println("Total de agentes inválidos " + numAgentesInvalidos);

        return solucion;
    }

    public Agente algoritmoEDBest2CambioPoblacion(Random ran){
        int NP = numAgentes;
        int numAgentesValidos = 0;
        int numAgentesInvalidos = 0;
        ArrayList<Agente> poblacionActualizadaAuxiliar = new ArrayList<>();

        double valorASuperar = (gamma*p.getConsistencia().getNivelConsistencia()) + ((1-gamma)*p.getConsenso().getNivelConsenso());
//        double valorASuperar = p.getConsenso().getNivelConsenso();

        double CR = 0.4;
        double F = 0.8;
        Agente solucion = null;
        float nuevoConsenso = 0;
        float nuevaConsistencia = 0;

        int numIteracciones = 0;
        while(numIteracciones < numIte){
            for(int i = 0; i < NP; i++){
                Agente agenteActual = this.copiarAgente(agentes.get(i));
                ArrayList<Integer> valores = escogerAgentes4(i, numAgentes - 1, ran);

                Agente a = agentes.get(valores.get(0));
                Agente b = agentes.get(valores.get(1));
                Agente c = agentes.get(valores.get(2));
                Agente d = agentes.get(valores.get(3));

                int R = ran.nextInt()%numValores + 1;

                for(int j = 0; j < numValores; j++){
                    double r = ran.nextDouble()%1;
                    if(r < CR || j == R){
                        double yi = agenteActual.getValor(j) + F * (a.getValor(j) - b.getValor(j)) + F * (c.getValor(j) - d.getValor(j));
//                        System.out.println("El valor de YI es " + yi);

                        if(yi > 1){
                            yi = 1;
                        }
                        if(yi < 0){
                            yi = 0;
                        }
                        agenteActual.setValor(Float.parseFloat(String.valueOf(yi)), j);
                    }
                }
                // Función que comprueba el agente
//                boolean agenteValido = obtenerDiferenciaGlobal(agenteActual);
                boolean agenteValido = obtenerDiferenciaIndividual(agenteActual);
                if(agenteValido){
                    numAgentesValidos += 1;
                    nuevoConsenso = this.calcularConsensoAgente(agenteActual.getVectorPesos());
                    nuevaConsistencia = this.calcularConsistenciaAgente(agenteActual.getVectorPesos());
                    double nuevoValor = (gamma*nuevaConsistencia) + ((1-gamma)*nuevoConsenso);
//                    double nuevoValor = nuevoConsenso;
//                    System.out.println(nuevoValor + " " + valorASuperar);
                    if(nuevoValor > valorASuperar) {
                        solucion = copiarAgente(agenteActual);
                        this.criterioOptimizacion.add(Float.parseFloat(String.valueOf(nuevoValor).substring(0, 5)));

                        this.mejorasConsenso.add(Float.parseFloat(String.valueOf(nuevoConsenso).substring(0, 5)));
                        consensoCalculado.setNivelConsenso(Float.parseFloat(String.valueOf(nuevoConsenso).substring(0, 5)));

                        this.mejorasConsistencia.add(Float.parseFloat(String.valueOf(nuevaConsistencia).substring(0, 5)));
                        consistenciaCalculada.setNivelConsistencia(Float.parseFloat(String.valueOf(nuevaConsistencia).substring(0, 5)));

                        valorASuperar = nuevoValor;
                        poblacionActualizadaAuxiliar.add(agenteActual);
                    }
                    else{
                        poblacionActualizadaAuxiliar.add(agentes.get(i));
                    }
                }
                else{
                    numAgentesInvalidos += 1;
                    poblacionActualizadaAuxiliar.add(agentes.get(i));
                }
            }

            for(int k = 0; k < agentes.size(); k++){
                agentes.set(k, poblacionActualizadaAuxiliar.get(k));
            }
            poblacionActualizadaAuxiliar = new ArrayList<>();
            numIteracciones++;
        }
        System.out.println("Total de agentes válidos " + numAgentesValidos);
        System.out.println("Total de agentes inválidos " + numAgentesInvalidos);

        return solucion;
    }

    public Agente algoritmoEDBestCambioF(Random ran){
        int NP = numAgentes;
        int numAgentesValidos = 0;
        int numAgentesInvalidos = 0;

        ArrayList<Double> valoresConseguidos = new ArrayList<>();

        double valorASuperar = (gamma*p.getConsistencia().getNivelConsistencia()) + ((1-gamma)*p.getConsenso().getNivelConsenso());
//        double valorASuperar = p.getConsenso().getNivelConsenso();
        double CR = 0.6;

        double F1 = 0.9;
        double F2 = 0.9;
        double Fu = 2;//Mayor
        double Fl = 0;

        Agente solucion = null;
        float nuevoConsenso = 0;
        float nuevaConsistencia = 0;

        int numIteracciones = 0;
        while(numIteracciones < numIte){
            for(int i = 0; i < NP; i++){
                Agente agenteActual = this.copiarAgente(agentes.get(i));
                ArrayList<Integer> valores = escogerAgentes4(i, numAgentes - 1, ran);

                Agente a = agentes.get(valores.get(0));
                Agente b = agentes.get(valores.get(1));
                Agente c = agentes.get(valores.get(2));
                Agente d = agentes.get(valores.get(3));

                int R = ran.nextInt()%numValores + 1;

                nuevoConsenso = this.calcularConsensoAgente(a.getVectorPesos());
//                nuevaConsistencia = this.calcularConsistenciaAgente(a.getVectorPesos());
//                double valorFitA = (gamma*nuevaConsistencia) + ((1-gamma)*nuevoConsenso);
                double valorFitA = nuevoConsenso;

                        nuevoConsenso = this.calcularConsensoAgente(b.getVectorPesos());
//                nuevaConsistencia = this.calcularConsistenciaAgente(b.getVectorPesos());
//                double valorFitB = (gamma*nuevaConsistencia) + ((1-gamma)*nuevoConsenso);
                double valorFitB = nuevoConsenso;

                nuevoConsenso = this.calcularConsensoAgente(c.getVectorPesos());
//                nuevaConsistencia = this.calcularConsistenciaAgente(c.getVectorPesos());
//                double valorFitC = (gamma*nuevaConsistencia) + ((1-gamma)*nuevoConsenso);
                double valorFitC = nuevoConsenso;

                nuevoConsenso = this.calcularConsensoAgente(d.getVectorPesos());
//                nuevaConsistencia = this.calcularConsistenciaAgente(d.getVectorPesos());
//                double valorFitD = (gamma*nuevaConsistencia) + ((1-gamma)*nuevoConsenso);
                double valorFitD = nuevoConsenso;

                for(int j = 0; j < numValores; j++){
                    double r = ran.nextDouble()%1;
                    if(r < CR || j == R){

                        F1 = Fl + (Fu - Fl) * ( (valorFitA - valorASuperar) / (valorFitB - valorASuperar) );
                        F2 = Fl + (Fu - Fl) * ( (valorFitC - valorASuperar) / (valorFitD - valorASuperar) );
                        double yi = agenteActual.getValor(j) + F1 * (a.getValor(j) - b.getValor(j)) + F2 * (c.getValor(j) - d.getValor(j));


                        if(yi > 1){
                            yi = 1;
                        }
                        if(yi < 0){
                            yi = 0;
                        }
                        agenteActual.setValor(Float.parseFloat(String.valueOf(yi)), j);
                    }
                }
                // Función que comprueba el agente
//                 boolean agenteValido = obtenerDiferenciaGlobal(agenteActual);
                boolean agenteValido = obtenerDiferenciaIndividual(agenteActual);
                if(agenteValido){
                    numAgentesValidos += 1;
                    nuevoConsenso = this.calcularConsensoAgente(agenteActual.getVectorPesos());
                    nuevaConsistencia = this.calcularConsistenciaAgente(agenteActual.getVectorPesos());
                    double nuevoValor = (gamma*nuevaConsistencia) + ((1-gamma)*nuevoConsenso);
//                    double nuevoValor = nuevoConsenso;
                    valoresConseguidos.add(nuevoValor);
                    if(nuevoValor > valorASuperar) {
                        solucion = copiarAgente(agenteActual);
                        this.criterioOptimizacion.add(Float.parseFloat(String.valueOf(nuevoValor).substring(0, 5)));

                        this.mejorasConsenso.add(Float.parseFloat(String.valueOf(nuevoConsenso).substring(0, 5)));
                        consensoCalculado.setNivelConsenso(Float.parseFloat(String.valueOf(nuevoConsenso).substring(0, 5)));

                        this.mejorasConsistencia.add(Float.parseFloat(String.valueOf(nuevaConsistencia).substring(0, 5)));
                        consistenciaCalculada.setNivelConsistencia(Float.parseFloat(String.valueOf(nuevaConsistencia).substring(0, 5)));

                        valorASuperar = nuevoValor;
                        for(int s = 0; s < agenteActual.getTamanio(); s++){
                            agentes.get(i).setValor(agenteActual.getValor(s), s);
                        }
                    }
                }
                else{
                    numAgentesInvalidos += 1;
                }
            }
            numIteracciones++;
        }
        System.out.println("Total de agentes válidos " + numAgentesValidos);
        System.out.println("Total de agentes inválidos " + numAgentesInvalidos);

        double media = 0;
        for(int i = 0; i < valoresConseguidos.size(); i++){
            media+=valoresConseguidos.get(i);
        }
        media = media/valoresConseguidos.size();
        System.out.println("La media que se obtiene es de " + media);
        return solucion;
    }

    public Agente copiarAgente(Agente ag){
        Agente agenteCopiado = new Agente();
        agenteCopiado.setTamanio(ag.getTamanio());
        for(int i = 0; i < ag.getTamanio(); i++){
            agenteCopiado.getVectorPesos().add(ag.getValor(i));
        }
        return agenteCopiado;
    }

    ArrayList<Integer> escogerAgentes3(int i, int numVa, Random ran){
        ArrayList<Integer> valores = new ArrayList<>();
        int a = ran.nextInt(numVa);
        int b = ran.nextInt(numVa);
        int c = ran.nextInt(numVa);

        while(a == i || a == b || a == c || b == i || b == c || c == i){
            if(a == i || a == b || a == c){
                a = ran.nextInt(numVa);
            }
            if(b == i || b == a || b == c){
                b = ran.nextInt(numVa);
            }
            if(c == i || c == b || c == a){
                c = ran.nextInt(numVa);
            }
        }
        valores.add(a);
        valores.add(b);
        valores.add(c);

        return valores;
    }

    ArrayList<Integer> escogerAgentes4(int i, int numVa, Random ran){
        ArrayList<Integer> valores = new ArrayList<>();

        int a = ran.nextInt(numVa);
        int b = ran.nextInt(numVa);
        int c = ran.nextInt(numVa);
        int d = ran.nextInt(numVa);

        while(a == i || a == b || a == c || a == d || b == i || b == c || b == d || c == i || c == d || d == i){
            if(a == i || a == b || a == c || a == d){
                a = ran.nextInt(numVa);
            }
            if(b == i || b == a || b == c || b == d){
                b = ran.nextInt(numVa);
            }
            if(c == i || c == a || c == b || c == d){
                c = ran.nextInt(numVa);
            }
            if(d == i || d == a || d == b || d == c){
                d = ran.nextInt(numVa);
            }
        }
        valores.add(a);
        valores.add(b);
        valores.add(c);
        valores.add(d);

        return valores;
    }

    float calcularConsensoAgente(ArrayList<Float> agente){
        ArrayList< ArrayList<Opinion>> opinionesModificadas = convertirAConjuntoOpiniones(agente);
        Consenso c = new Consenso();
        c.funcionNivelConsenso(opinionesModificadas, p.getExpertos().size(), p.getCriterios());

        return c.getNivelConsenso();
    }

    float calcularConsistenciaAgente(ArrayList<Float> agente){
        ArrayList< ArrayList<Opinion>> opinionesModificadas = convertirAConjuntoOpiniones(agente);
        Consistencia c = new Consistencia();
        ArrayList<Float> pesosCriterios = new ArrayList<>();
        for(int i = 0; i < p.getExpertos().size(); i++){
            for(int j = 0; j < p.getExperto(i).getPesosCriterios().size(); j++){
                pesosCriterios.add(p.getExperto(i).getPesosCriterios().get(j));
            }
        }
        c.funcionNivelConsistencia(opinionesModificadas, p.getExpertos().size(), p.getAlternativas(), pesosCriterios);

        return c.getNivelConsistencia();
    }

    public ArrayList< ArrayList<Opinion>> convertirAConjuntoOpiniones(ArrayList<Float> agente){
        int numExpertos = p.getExpertos().size();
        int numAlternativas = p.getAlternativas();
        int numCriterios = p.getCriterios();

        ArrayList<Float> agenteAuxiliar = new ArrayList<>();
        for(int i = 0; i < agente.size(); i++){
            agenteAuxiliar.add(agente.get(i));
        }

        ArrayList< ArrayList<Opinion>> opinionesNuevas = new ArrayList<>();

        for(int i = 0; i < numExpertos; i++){
            ArrayList<Opinion> opinionExperto = new ArrayList<>();
            for(int j = 0; j < numCriterios; j++){
                Opinion aux = new Opinion(agenteAuxiliar, numAlternativas);
                opinionExperto.add(aux);
            }
            opinionesNuevas.add(opinionExperto);
        }
        return opinionesNuevas;
    }


    boolean obtenerDiferenciaGlobal(Agente solucionParcial){
        ArrayList<ArrayList<Opinion>> opinionesIniciales = p.getOpiniones();
        ArrayList<ArrayList<Opinion>> opinionesAgente = this.convertirAConjuntoOpiniones(solucionParcial.getVectorPesos());
        double suma = 0;
        for(int i = 0; i < p.getExpertos().size(); i++){
            for(int j = 0; j < p.getCriterios(); j++){
                for(int x = 0; x < p.getAlternativas(); x++){
                    for(int y = 0; y < p.getAlternativas(); y++){
                        suma += Math.abs(opinionesIniciales.get(i).get(j).getOpinion()[x][y]-
                                opinionesAgente.get(i).get(j).getOpinion()[x][y]);
                    }
                }
            }
        }
        suma = suma / solucionParcial.getVectorPesos().size();
        if(suma <= alpha * 0.5)
            return true;
        else
           return false;
    }

    boolean obtenerDiferenciaIndividual(Agente solucionParcial){
        ArrayList<ArrayList<Opinion>> opinionesIniciales = p.getOpiniones();
        ArrayList<ArrayList<Opinion>> opinionesAgente = this.convertirAConjuntoOpiniones(solucionParcial.getVectorPesos());
        int valoresSumados = ((p.getAlternativas()*p.getAlternativas()) - p.getAlternativas());

        double suma = 0;
        for(int i = 0; i < p.getExpertos().size(); i++){
            for(int j = 0; j < p.getCriterios(); j++){
                for(int x = 0; x < p.getAlternativas(); x++){
                    for(int y = 0; y < p.getAlternativas(); y++){
                        if(x != y)
                            suma += Math.abs(opinionesIniciales.get(i).get(j).getOpinion()[x][y]-
                                opinionesAgente.get(i).get(j).getOpinion()[x][y]);
                    }
                }

                double sumaFinal = suma / valoresSumados;
                if(sumaFinal >= (alpha * 0.5))
                    return false;

                suma = 0;
            }
        }
        return true;
    }

    public boolean obtenerDiferenciaUniforme(Agente solucionParcial){
        ArrayList<ArrayList<Opinion>> opinionesIniciales = p.getOpiniones();
        ArrayList<ArrayList<Opinion>> opinionesAgente = this.convertirAConjuntoOpiniones(solucionParcial.getVectorPesos());

        for(int i = 0; i < p.getExpertos().size(); i++){
            for(int j = 0; j < p.getCriterios(); j++){
                for(int x = 0; x < p.getAlternativas(); x++){
                    for(int y = 0; y < p.getAlternativas(); y++){
                        double valorReferencia = opinionesIniciales.get(i).get(j).getOpinion()[x][y];
                        double intervaloArriba = valorReferencia + (alpha/2);
                        double intervaloAbajo = valorReferencia - (alpha/2);
                        //System.out.println("El intervalo es [" + intervaloAbajo +" , " + intervaloArriba + "]");
                        if(opinionesAgente.get(i).get(j).getOpinion()[x][y] > intervaloArriba
                        || opinionesAgente.get(i).get(j).getOpinion()[x][y] < intervaloAbajo){
                            return false;
                        }
                    }
                }
            }
        }
        return true;
    }

    public void mostrarResultadosAlgoritmo(){
        System.out.println("Mejoras de Consistencia");
        for(int i = 0; i < mejorasConsistencia.size(); i++){
            System.out.print(mejorasConsistencia.get(i) + " ");
        }
        System.out.println();

        System.out.println("Mejoras de Consenso");
        for(int i = 0; i < mejorasConsenso.size(); i++){
            System.out.print(mejorasConsenso.get(i) + " ");
        }
        System.out.println();

        System.out.println("Mejoras de Gamma");
        for(int i = 0; i < criterioOptimizacion.size(); i++){
            System.out.print(criterioOptimizacion.get(i) + " ");
        }
        System.out.println();
        System.out.println();
        System.out.println("Consistencia final " + this.consistenciaCalculada.getNivelConsistencia());
        System.out.println("Consenso final " + this.consensoCalculado.getNivelConsenso());
        System.out.println();
    }

    public void mostrarResultadosAlgoritmoEstudio(){
        System.out.println("Mejoras de Consistencia");
        System.out.print(mejorasConsistencia.get(mejorasConsistencia.size()-1) + " ");
        System.out.println();

        System.out.println("Mejoras de Consenso");
        System.out.print(mejorasConsenso.get(mejorasConsenso.size()-1) + " ");
        System.out.println();

        System.out.println("Mejoras de Gamma");
        System.out.print(criterioOptimizacion.get(criterioOptimizacion.size()-1) + " ");
        System.out.println();
        System.out.println();
        System.out.println("Consistencia final " + this.consistenciaCalculada.getNivelConsistencia());
        System.out.println("Consenso final " + this.consensoCalculado.getNivelConsenso());
        System.out.println();
    }


    public Enjambre algoritmoPSO(Random ran, float consistencia, float consenso) {
        ArrayList<Particula> particulas = new ArrayList<>();

        ArrayList<Float> arrayCriterios = new ArrayList<>();
        for(int i = 0; i < p.getCriterios(); i++){
            arrayCriterios.add((float) 1);
        }

        int tamanio = this.numValores;
        int numIteracciones = 0;
        double wp = 2;
        double wy = 2;
        int numMasInteracciones = 300;
        ArrayList<Float> opinionesVector = convertirAAgente(p.getOpiniones());

        for(int i = 0; i < 150; i++) {
            Particula aux = new Particula(tamanio, ran, alpha, opinionesVector);
            particulas.add(aux);
        }

        Enjambre enjambre = new Enjambre(particulas, consistencia, consenso, (float) gamma);

        while(numIteracciones < numMasInteracciones){
            double w = (0.5)*(((numMasInteracciones-numIteracciones)/numMasInteracciones)+0.4);
            for(int i = 0; i < particulas.size(); i++){
                for(int d = 0; d < tamanio; d++){
                    double rp = ran.nextDouble();
                    double rg = ran.nextDouble();
                    particulas.get(i).setValorVectorVelocidad(d, (float) ((w*(particulas.get(i).getVectorVelocidad().get(d))) + wp*rp*(particulas.get(i).getVectorMejorPosicion().get(d) - particulas.get(i).getVectorPosicion().get(d)) + wy*rg*(enjambre.getVectorMejorPosicion().get(d) -particulas.get(i).getVectorPosicion().get(d))));

                    if (particulas.get(i).getVectorVelocidad().get(d) > 0.1) {
                        particulas.get(i).setValorVectorVelocidad(d, (float) 0.1);
                    }
                    if (particulas.get(i).getVectorVelocidad().get(d) < -0.1) {
                        particulas.get(i).setValorVectorVelocidad(d, (float) -0.1);
                    }
                    particulas.get(i).setValorVectorPosicion(d, particulas.get(i).getVectorPosicion().get(d) + particulas.get(i).getVectorVelocidad().get(d));

                    if(particulas.get(i).getVectorPosicion().get(d) < 0){
                        particulas.get(i).getVectorPosicion().set(d, (float) 0);
                    }
                    if(particulas.get(i).getVectorPosicion().get(d) > 1){
                        particulas.get(i).getVectorPosicion().set(d, (float) 1);
                    }
                }
                ArrayList<Double> q = calcularQ(particulas.get(i).getVectorPosicion(), ran);

                if(q.get(0) > particulas.get(i).getMejorValor(0)){
                    for(int k = 0; k < particulas.get(i).getMejoresValores().size(); k++){
                        particulas.get(i).setValorMejoresValores(k, Float.parseFloat(String.valueOf(q.get(k))));
                    }
                    for(int k = 0; k < particulas.get(i).getVectorMejorPosicion().size(); k++){
                        float aux = particulas.get(i).getVectorPosicion().get(k);
                        particulas.get(i).setValorVectorMejorPosicion(aux, k);
                    }
//                    System.out.println(enjambre.getMejorValoracionGlobal().get(0));
                    if(q.get(0) > enjambre.getMejorValoracionGlobal().get(0)){
//                        System.out.println(q.get(0));
                        for(int k = 0; k < enjambre.getMejorValoracionGlobal().size(); k++){
                            enjambre.setMejorValoracionGlobal(Float.parseFloat(String.valueOf(q.get(k))), k);
                        }
                        for(int k = 0; k < particulas.get(i).getVectorMejorPosicion().size(); k++){
                            float aux = particulas.get(i).getVectorMejorPosicion().get(k);
                            enjambre.setVectorMejorPosicion(aux, k);
                        }
                    }
                }
            }
            enjambre.setValoresQs(enjambre.getMejorValoracionGlobal());
            numIteracciones++;
        }
        return enjambre;
    }


    public Enjambre algoritmoPSOSalerno(Random ran, float consistencia, float consenso, float valorEntropia) {
        ArrayList<Particula> particulas = new ArrayList<>();

        ArrayList<Float> arrayCriterios = new ArrayList<>();
        for(int i = 0; i < p.getCriterios(); i++){
            arrayCriterios.add((float) 1);
        }

        int tamanio = this.numValores;
        int numIteracciones = 0;
        double wp = 2;
        double wy = 2;
        int numMasInteracciones = 300;
        ArrayList<Float> opinionesVector = convertirAAgente(p.getOpiniones());

        for(int i = 0; i < 150; i++) {
            Particula aux = new Particula(tamanio, ran, alpha, opinionesVector);
            particulas.add(aux);
        }
        Enjambre enjambre = new Enjambre(particulas, consistencia, consenso, valorEntropia, (float) gamma);

        while(numIteracciones < numMasInteracciones){
            double w = (0.5)*(((numMasInteracciones-numIteracciones)/numMasInteracciones)+0.4);
            for(int i = 0; i < particulas.size(); i++){
                for(int d = 0; d < tamanio; d++){
                    double rp = ran.nextDouble();
                    double rg = ran.nextDouble();
                    particulas.get(i).setValorVectorVelocidad(d, (float) ((w*(particulas.get(i).getVectorVelocidad().get(d))) + wp*rp*(particulas.get(i).getVectorMejorPosicion().get(d) - particulas.get(i).getVectorPosicion().get(d)) + wy*rg*(enjambre.getVectorMejorPosicion().get(d) -particulas.get(i).getVectorPosicion().get(d))));

                    if (particulas.get(i).getVectorVelocidad().get(d) > 0.1) {
                        particulas.get(i).setValorVectorVelocidad(d, (float) 0.1);
                    }
                    if (particulas.get(i).getVectorVelocidad().get(d) < -0.1) {
                        particulas.get(i).setValorVectorVelocidad(d, (float) -0.1);
                    }
                    particulas.get(i).setValorVectorPosicion(d, particulas.get(i).getVectorPosicion().get(d) + particulas.get(i).getVectorVelocidad().get(d));

                    if(particulas.get(i).getVectorPosicion().get(d) < 0){
                        particulas.get(i).getVectorPosicion().set(d, (float) 0);
                    }
                    if(particulas.get(i).getVectorPosicion().get(d) > 1){
                        particulas.get(i).getVectorPosicion().set(d, (float) 1);
                    }
                }
                ArrayList<Double> q = calcularQSalerno(particulas.get(i).getVectorPosicion(), ran);
//                System.out.println(q.get(0) + " " + particulas.get(i).getMejorValor(0));
                if(q.get(0) > particulas.get(i).getMejorValor(0)){
                    for(int k = 0; k < particulas.get(i).getMejoresValores().size(); k++){
                        particulas.get(i).setValorMejoresValores(k, Float.parseFloat(String.valueOf(q.get(k))));
                    }
                    for(int k = 0; k < particulas.get(i).getVectorMejorPosicion().size(); k++){
                        float aux = particulas.get(i).getVectorPosicion().get(k);
                        particulas.get(i).setValorVectorMejorPosicion(aux, k);
                    }
//                    System.out.println(enjambre.getMejorValoracionGlobal().get(0));
//                    System.out.println("Enjambre " + q.get(0) + " " + enjambre.getMejorValoracionGlobal().get(0));
                    if(q.get(0) > enjambre.getMejorValoracionGlobal().get(0)){
//                        System.out.println(q.get(0));
                        for(int k = 0; k < enjambre.getMejorValoracionGlobal().size(); k++){
                            enjambre.setMejorValoracionGlobal(Float.parseFloat(String.valueOf(q.get(k))), k);
                        }
                        for(int k = 0; k < particulas.get(i).getVectorMejorPosicion().size(); k++){
                            float aux = particulas.get(i).getVectorMejorPosicion().get(k);
                            enjambre.setVectorMejorPosicion(aux, k);
                        }
                    }
                }
            }
            enjambre.setValoresQs(enjambre.getMejorValoracionGlobal());
            numIteracciones++;
        }
        return enjambre;
    }



    boolean diferenciaValor1Protocolo(ArrayList<Float> vectorPosicion){ //Uniforme
        ArrayList<ArrayList<Opinion>> opinionesIniciales = p.getOpiniones();
        ArrayList<ArrayList<Opinion>> opinionesAgente = this.convertirAConjuntoOpiniones(vectorPosicion);
        double intervaloSuperior;
        double intervaloInferior;
        for(int i = 0; i < p.getExpertos().size(); i++){
            for(int j = 0; j < p.getCriterios(); j++){
                for(int x = 0; x < p.getAlternativas(); x++){
                    for(int y = 0; y < p.getAlternativas(); y++){
                        if(x != y) {
                            double valorActual = opinionesAgente.get(i).get(j).getOpinion()[x][y];
                            intervaloSuperior = opinionesIniciales.get(i).get(j).getOpinion()[x][y] + (alpha/2);
                            intervaloInferior = opinionesIniciales.get(i).get(j).getOpinion()[x][y] - (alpha/2);

                            if(valorActual > intervaloSuperior || valorActual < intervaloInferior){
                                return false;
                            }
                        }
                    }
                }
            }
        }
        return true;
    }

    boolean diferenciaValor2Protocolo(ArrayList<Float> vectorPosicion, Random ran){
        ArrayList<ArrayList<Opinion>> opinionesIniciales = p.getOpiniones();
        ArrayList<ArrayList<Opinion>> opinionesAgente = this.convertirAConjuntoOpiniones(vectorPosicion);
        double intervaloSuperior;
        double intervaloInferior;
        int contador = 0;
        float y1;
//        int n = p.getNumExpertos()*p.getCriterios()*((p.getAlternativas()*p.getAlternativas())-p.getAlternativas());
        int n = (p.getAlternativas()*p.getAlternativas())-p.getAlternativas();

        double fraccion = (double)1 / n;
//        System.out.println("La fraccion vale " + fraccion);
        for(int i = 0; i < p.getExpertos().size(); i++){
            for(int j = 0; j < p.getCriterios(); j++){
                for(int x = 0; x < p.getAlternativas(); x++){
                    for(int y = 0; y < p.getAlternativas(); y++){
                        if(x != y) {
                            double valorActual = opinionesAgente.get(i).get(j).getOpinion()[x][y];
                            if(contador%2==0){
//                                y1 = (float) ran.nextDouble();
//                                intervaloInferior = opinionesIniciales.get(i).get(j).getOpinion()[x][y] - (fraccion * alpha * y1);
//                                intervaloSuperior = opinionesIniciales.get(i).get(j).getOpinion()[x][y] + (fraccion * alpha * (1-y1));

                                intervaloInferior = opinionesIniciales.get(i).get(j).getOpinion()[x][y] - alpha;
                                intervaloSuperior = opinionesIniciales.get(i).get(j).getOpinion()[x][y] + alpha;
                            }
                            else{
//                                y1 = (float) ran.nextDouble();
//                                intervaloInferior = opinionesIniciales.get(i).get(j).getOpinion()[x][y] - (fraccion * alpha * (1-y1));
//                                intervaloSuperior = opinionesIniciales.get(i).get(j).getOpinion()[x][y] + (fraccion * alpha * y1);

                                intervaloInferior = opinionesIniciales.get(i).get(j).getOpinion()[x][y] - alpha;
                                intervaloSuperior = opinionesIniciales.get(i).get(j).getOpinion()[x][y] + alpha;
                            }
//                            System.out.println(intervaloInferior + " " + valorActual + " " + intervaloSuperior);
                            if(valorActual > intervaloSuperior || valorActual < intervaloInferior){
                                return false;
                            }
                        }
                        contador++;
                    }
                }
            }
        }
        return true;
    }


    boolean diferenciaValor4ProtocoloCabrerizo(ArrayList<Float> vectorPosicion, Random ran){
        ArrayList<ArrayList<Opinion>> opinionesIniciales = p.getOpiniones();
        ArrayList<ArrayList<Opinion>> opinionesAgente = this.convertirAConjuntoOpiniones(vectorPosicion);;
        double intervaloSuperior;
        double intervaloInferior;
        float y1, y2;
        int contador = 0;
        boolean continuar = false;
        while(continuar == false){
            opinionesAgente = this.convertirAConjuntoOpiniones(vectorPosicion);
            for(int i = 0; i < p.getExpertos().size(); i++){
                for(int j = 0; j < p.getCriterios(); j++){
                    for(int x = 0; x < p.getAlternativas(); x++){
                        for(int y = 0; y < p.getAlternativas(); y++){
                            if(x != y) {
                                double valorActual = opinionesAgente.get(i).get(j).getOpinion()[x][y];
//                                y1 = (float) ran.nextDouble();
//                                y2 = (float) ran.nextDouble();
                                intervaloInferior = opinionesIniciales.get(i).get(j).getOpinion()[x][y] - 0.3;
                                intervaloSuperior = opinionesIniciales.get(i).get(j).getOpinion()[x][y] + 0.3;

//                                System.out.println("[" + intervaloInferior + ", " + intervaloSuperior+"]");
//                                System.out.println(valorActual + " " + opinionesIniciales.get(i).get(j).getOpinion()[x][y]);
                                if(valorActual <= intervaloSuperior && valorActual >= intervaloInferior){
                                    continuar = true;
                                }
                                else{
                                    vectorPosicion.set(contador, (float) ran.nextDouble());
                                }
                                contador++;
                            }
                        }
                    }
                }
            }
            contador = 0;
        }
        opinionesAgente = this.convertirAConjuntoOpiniones(vectorPosicion);
        double diferencia = 0;
        for(int i = 0; i < p.getExpertos().size(); i++){
            for(int j = 0; j < p.getCriterios(); j++){
                for(int x = 0; x < p.getAlternativas(); x++){
                    for(int y = 0; y < p.getAlternativas(); y++){
                        if(x != y) {
                            diferencia += Math.abs(opinionesIniciales.get(i).get(j).getOpinion()[x][y] - opinionesAgente.get(i).get(j).getOpinion()[x][y]);
                        }
                    }
                }
//                System.out.println(diferencia + " " + alpha*((p.getAlternativas()*p.getAlternativas()) - p.getAlternativas()));
                if(diferencia > alpha*((p.getAlternativas()*p.getAlternativas()) - p.getAlternativas())){
                    return false;
                }
                else{
                    diferencia=0;
                }
            }
        }

        return true;
    }


    boolean diferenciaValor4Protocolo(ArrayList<Float> vectorPosicion, Random ran){
        ArrayList<ArrayList<Opinion>> opinionesIniciales = p.getOpiniones();
        ArrayList<ArrayList<Opinion>> opinionesAgente = this.convertirAConjuntoOpiniones(vectorPosicion);
        int valoresSumados = ((p.getAlternativas()*p.getAlternativas()) - p.getAlternativas());

        double suma = 0;
        for(int i = 0; i < p.getExpertos().size(); i++){
            for(int j = 0; j < p.getCriterios(); j++){
                for(int x = 0; x < p.getAlternativas(); x++){
                    for(int y = 0; y < p.getAlternativas(); y++){
                        if(x != y)
                            suma += Math.abs(opinionesIniciales.get(i).get(j).getOpinion()[x][y]-
                                    opinionesAgente.get(i).get(j).getOpinion()[x][y]);
                    }
                }
                double sumaFinal = suma / valoresSumados;

                if(sumaFinal >= alpha)
                    return false;
//                System.out.println("Suma vale " + sumaFinal + " y no puede superar " + (alpha * 0.5));
                suma = 0;
            }
        }
        return true;
    }

    boolean diferenciaValor3Protocolo(ArrayList<Float> vectorPosicion){//Optimo
        ArrayList<ArrayList<Opinion>> opinionesIniciales = p.getOpiniones();
        ArrayList<ArrayList<Opinion>> opinionesAgente = this.convertirAConjuntoOpiniones(vectorPosicion);
        int valoresSumados = ((p.getAlternativas()*p.getAlternativas()) - p.getAlternativas());

        double suma = 0;
        for(int i = 0; i < p.getExpertos().size(); i++){
            for(int j = 0; j < p.getCriterios(); j++){
                for(int x = 0; x < p.getAlternativas(); x++){
                    for(int y = 0; y < p.getAlternativas(); y++){
                        if(x != y)
                            suma += Math.abs(opinionesIniciales.get(i).get(j).getOpinion()[x][y]-
                                    opinionesAgente.get(i).get(j).getOpinion()[x][y]);
                    }
                }
                double sumaFinal = suma / valoresSumados;

                if(sumaFinal >= (alpha * 0.5))
                    return false;
//                System.out.println("Suma vale " + sumaFinal + " y no puede superar " + (alpha * 0.5));
                suma = 0;
            }
        }
        return true;
    }


    public void mostrarValoresParticulaVectorPosicion(ArrayList<Float> vectorPosicionParticula){
        for(int i = 0; i < vectorPosicionParticula.size(); i++){
            System.out.print(vectorPosicionParticula.get(i) + " ");
        }
        System.out.println();
    }

    private ArrayList<Double> calcularQ(ArrayList<Float> vectorPosicion, Random ran){

        ArrayList<Float> pesosCriterios = new ArrayList<>();
        for(int i = 0; i < p.getExpertos().size(); i++){
            for(int j = 0; j < p.getExperto(i).getPesosCriterios().size(); j++){
                pesosCriterios.add(p.getExperto(i).getPesosCriterios().get(j));
            }
        }
        ArrayList<ArrayList<Opinion>> auxiliar = this.convertirAConjuntoOpiniones(vectorPosicion);
        ArrayList<Double> resultados = new ArrayList<>();

//        if(diferenciaValor4Protocolo(vectorPosicion, ran)){
//        if(diferenciaValor3Protocolo(vectorPosicion)){
        if(diferenciaValor2Protocolo(vectorPosicion, ran)){
//        if(diferenciaValor1Protocolo(vectorPosicion)){
            double q1 = consistenciaCalculada.funcionNivelConsistencia(auxiliar, auxiliar.size(), auxiliar.get(0).get(0).getFilcolum(), pesosCriterios);
            double q2 = consensoCalculado.funcionNivelConsenso(auxiliar, auxiliar.size(), auxiliar.get(0).size());
            //double q3 = calculoQ3(auxiliar, p.getOpiniones());
            double q=gamma*q2 + (1-gamma)*q1;
//            System.out.println("El valor de Q2 es " + q2);
//            System.out.println("El valor de Q3 es " + q3);
//            System.out.println("El valor de Q es " + q);
            resultados.add(q);
            resultados.add(q);
            resultados.add(q);
//            System.out.println(q2+ " " + q);
        }
        else{
            resultados.add((double) 0);
            resultados.add((double) 0);
            resultados.add((double) 0);
        }
//        System.out.println("Contador Bueno " + contadorBueno + " contador Malo " + contadorMalo);
        return resultados;
    }
    public float logBase2(float x) {
        return (float) (Math.log(x) / Math.log(2));
    }
    public float obtenerEntropiaExperto(Opinion opinion){
        float entropia, auxiliar = 0;
        int division = opinion.getFilcolum() * opinion.getFilcolum() - opinion.getFilcolum();
        for(int i = 0; i < opinion.getFilcolum(); i++){
            for(int j = 0; j < opinion.getFilcolum(); j++){
                if(i!=j){
                    float inverso = 1 - opinion.getOpinion()[i][j];
                    if(inverso > 0 && inverso < 1) {
                        auxiliar += (opinion.getOpinion()[i][j] * logBase2(opinion.getOpinion()[i][j])) + (inverso * logBase2(inverso));
                    }
                    else{
                        auxiliar += 0;
                    }
                }
            }
        }
//		System.out.println("La entoripa es " + auxiliar + " y se divide por " + division);
        entropia = (auxiliar / division)*-1;
//		System.out.println("Entropia por experto " + entropia);
        return entropia;
    }


    public double obtenerEntropiaProblema(ArrayList<ArrayList<Opinion>> problema){
        double entropiaMedia = 0;

        for(int i = 0; i < problema.size(); i++){
            entropiaMedia+=obtenerEntropiaExperto(problema.get(i).get(0));
        }
        entropiaMedia = entropiaMedia / problema.size();
//		System.out.println("La entropia media es " + entropiaMedia);
        return entropiaMedia;
    }


    private ArrayList<Double> calcularQSalerno(ArrayList<Float> vectorPosicion, Random ran){

        ArrayList<Float> pesosCriterios = new ArrayList<>();
        for(int i = 0; i < p.getExpertos().size(); i++){
            for(int j = 0; j < p.getExperto(i).getPesosCriterios().size(); j++){
                pesosCriterios.add(p.getExperto(i).getPesosCriterios().get(j));
            }
        }
        ArrayList<ArrayList<Opinion>> auxiliar = this.convertirAConjuntoOpiniones(vectorPosicion);
        ArrayList<Double> resultados = new ArrayList<>();
        if(diferenciaValor2Protocolo(vectorPosicion, ran)){
            double q1 = consistenciaCalculada.funcionNivelConsistencia(auxiliar, auxiliar.size(), auxiliar.get(0).get(0).getFilcolum(), pesosCriterios);
            double q2 = consensoCalculado.funcionNivelConsenso(auxiliar, auxiliar.size(), auxiliar.get(0).size());
            double valorEntropia = this.obtenerEntropiaProblema(auxiliar);

//            double q=gamma*q2 + (1-gamma)*q1;
//            double q=gamma*q2 + (1-gamma)*q2;
//            double q = gamma*q2 + (1-gamma)*(1-valorEntropia);
//            double q = (q2*q2) / (1 + (1-valorEntropia));
//            double q = 0.5*q2 + 0.25*q1 + (1-valorEntropia)*0.25;
            double q = (q2*q2*q1) / (1 + (1-valorEntropia));
//            double q = ((q2*q2*gamma) + ((1-gamma)*q1)) / (1 + (1-valorEntropia));
//            double q = 0.7*q2 + 0.3*(1-valorEntropia);


//            double q=gamma*q2 + (1-gamma)*q1;
//            double q=gamma*valoresPreferenciaAlternativa + (1-gamma)*valoresPreferenciaAlternativa;
//            double q=gamma*q2 + (1-gamma)*q2;
//            System.out.println("Consenso: " + q2 + " valor " + valoresPreferenciaAlternativa + " q " + q);
            resultados.add(q);
            resultados.add(q2);
            resultados.add(valorEntropia);
        }
        else{
            resultados.add((double) 0);
            resultados.add((double) 0);
            resultados.add((double) 0);
        }
//        System.out.println("Contador Bueno " + contadorBueno + " contador Malo " + contadorMalo);
        return resultados;
    }

    public Double calculoQ3(ArrayList<ArrayList<Opinion>> auxiliar, ArrayList<ArrayList<Opinion>> opinionesIniciales){
        ArrayList<ArrayList<Opinion>> auxDiferencia = diferencia(auxiliar, opinionesIniciales);

        int iteracciones = p.getNumExpertos()*p.getCriterios()*((p.getAlternativas()*p.getAlternativas())-p.getAlternativas());
        double suma = 0;
        for(int i = 0; i < opinionesIniciales.size(); i++) {
            for (int j = 0; j < opinionesIniciales.get(i).size(); j++) {
                for (int x = 0; x < opinionesIniciales.get(i).get(j).getFilcolum(); x++) {
                    for (int y = 0; y < opinionesIniciales.get(i).get(j).getFilcolum(); y++) {
                        if(x!=y) {
                            suma += auxDiferencia.get(i).get(j).getOpinion()[x][y];
                        }
                    }
                }
            }
        }
        suma = suma / iteracciones;
        suma = 1 - suma;
//        System.out.println("La suma vale suma " + suma);
        return suma;
    }

    public ArrayList<ArrayList<Opinion>> diferencia(ArrayList<ArrayList<Opinion>> opinionesParticula, ArrayList<ArrayList<Opinion>> opinionesIniciales){
        ArrayList<ArrayList<Opinion>> resultado = new ArrayList<>();

        for(int i = 0; i < opinionesIniciales.size(); i++) {
            ArrayList<Opinion> opinionesExperto = new ArrayList<>();
            for (int j = 0; j < opinionesIniciales.get(i).size(); j++) {
                Opinion auxiliar = new Opinion(opinionesParticula.get(0).get(0).getFilcolum());
                for (int x = 0; x < opinionesIniciales.get(i).get(j).getFilcolum(); x++) {
                    for (int y = 0; y < opinionesIniciales.get(i).get(j).getFilcolum(); y++) {
                        float resta = Math.abs(opinionesIniciales.get(i).get(j).getOpinion()[x][y] - opinionesParticula.get(i).get(j).getOpinion()[x][y]);
                        auxiliar.getOpinion()[x][y] = resta;
                    }
                }
                opinionesExperto.add(auxiliar);
            }
            resultado.add(opinionesExperto);
        }
        return resultado;
    }

    private ArrayList<ArrayList<Opinion>> calcularZ(ArrayList<ArrayList<Opinion>> opinionesIniciales, double alpha, ArrayList<Float> vectorPosicion){
        double a, b, z;
        int contador = 0;
        ArrayList<ArrayList<Opinion>> opinionesAuxiliares = new ArrayList<>();
        for(int i = 0; i < opinionesIniciales.size(); i++){
            ArrayList<Opinion> opinionesExperto = new ArrayList<>();
            for(int j = 0; j < opinionesIniciales.get(i).size(); j++){
                Opinion aux = new Opinion(opinionesIniciales.get(i).get(j).getFilcolum());
                for(int x = 0; x < opinionesIniciales.get(i).get(j).getFilcolum(); x++) {
                    for (int y = 0; y < opinionesIniciales.get(i).get(j).getFilcolum(); y++) {
                        if(x!=y){
                            aux.getOpinion()[x][y] = opinionesIniciales.get(i).get(j).getOpinion()[x][y];
                        }
                    }
                }
                opinionesExperto.add(aux);
            }
            opinionesAuxiliares.add(opinionesExperto);
        }


        for(int i = 0; i < opinionesIniciales.size(); i++) {
            for (int j = 0; j < opinionesIniciales.get(i).size(); j++) {
                for (int x = 0; x < opinionesIniciales.get(i).get(j).getFilcolum(); x++) {
                    for (int y = 0; y < opinionesIniciales.get(i).get(j).getFilcolum(); y++) {
                        if(x!=y){
                            double aux = opinionesAuxiliares.get(i).get(j).getOpinion()[x][y] - (alpha/2);
                            if(aux > 0){
                                a=aux;
                            }
                            else{
                                a = 0;
                            }

                            aux = opinionesAuxiliares.get(i).get(j).getOpinion()[x][y] + (alpha/2);
                            if(1 > aux){
                                b=aux;
                            }
                            else{
                                b = 1;
                            }
                            z = a+((b-a) * vectorPosicion.get(contador));

                            if(z > opinionesIniciales.get(i).get(j).getOpinion()[x][y] + (alpha/2))
                                z = opinionesIniciales.get(i).get(j).getOpinion()[x][y] + (alpha/2);
                            if(z < opinionesIniciales.get(i).get(j).getOpinion()[x][y] - (alpha/2))
                                z = opinionesIniciales.get(i).get(j).getOpinion()[x][y] - (alpha/2);
                            if(z < 0)
                                z = 0;
                            if(z > 1)
                                z = 1;

                            contador++;
                            opinionesAuxiliares.get(i).get(j).getOpinion()[x][y] = (float) z;
                        }
                    }
                }
            }
        }
        return opinionesAuxiliares;
    }





























    public void setAlpha(double valor){
        alpha = valor;
    }

    public void setGamma(double valor){
        gamma = valor;
    }

    public void mostrarOpiniones(ArrayList<ArrayList<Opinion>> opiniones){
        for(int i = 0; i < opiniones.size(); i++) {
            for (int j = 0; j < opiniones.get(i).size(); j++) {
                for (int x = 0; x < opiniones.get(i).get(j).getFilcolum(); x++) {
                    for (int y = 0; y < opiniones.get(i).get(j).getFilcolum(); y++) {
                        if(x!=y)
                            System.out.print(opiniones.get(i).get(j).getOpinion()[x][y] + "\t");
                        else
                            System.out.print( "- \t");
                    }
                    System.out.println();
                }
                System.out.println();
            }
            System.out.println();
        }
    }
}
