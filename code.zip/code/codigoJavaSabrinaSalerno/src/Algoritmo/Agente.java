package Algoritmo;

import Modelo.Opinion;

import java.util.ArrayList;
import java.util.Random;

public class Agente {

    private ArrayList<Float> vectorPesos;
    private int tamanio;

    Agente(){
        vectorPesos = new ArrayList<>();
        tamanio = 0;
    }

    public Agente(int numValores, double alpha, ArrayList<Float> opiIniciales, Random ran){
        vectorPesos = new ArrayList<>();
        double low;
        double high;

        for(int i = 0; i < numValores; i++){
            float opinion = opiIniciales.get(i);
            high = opinion+(alpha/2);
            low = opinion-(alpha/2);

            double r = (ran.nextDouble() * (high - low)) + low;
            if (r > 1){
                r = 1;
            }

            if (r < 0){
                r = 0;
            }

            vectorPesos.add(Float.parseFloat(String.valueOf(r)));
        }

        tamanio = numValores;
    }

    public void mostrarAgente(int numExpertos, int numCriterios, int numAlternativas){
        int contador = 0;
        System.out.println("Los valores del agente son: ");
        for(int i = 0; i < numExpertos; i++){
            System.out.println("Experto " + i);
            for(int j = 0; j < numCriterios; j++){
                System.out.println("Criterio "+j);
                for(int x = 0; x < numAlternativas; x++){
                    for(int y = 0; y < numAlternativas; y++){
                        if(x!=y){
                            if(vectorPesos.get(contador).toString().length() > 3)
                                System.out.print(String.valueOf(vectorPesos.get(contador)).substring(0,4) + "\t");
                            else
                                System.out.print(String.valueOf(vectorPesos.get(contador)).substring(0,3) + "\t");
                            contador++;
                        }
                        else{
                            System.out.print("-\t");
                        }
                    }
                    System.out.println();
                }
                System.out.println();
            }
            System.out.println();
        }
        System.out.println();
    }

    public int getTamanio(){
        return tamanio;
    }

    public Float getValor(int i){
        return vectorPesos.get(i);
    }

    void setValor(Float valor, int pos){
        vectorPesos.set(pos, valor);
    }

    void aniadirValor(Float valor){
        vectorPesos.add(valor);
    }

    public ArrayList<Float> getVectorPesos(){
        return vectorPesos;
    }

    void setTamanio(int tam){
        tamanio = tam;
    }
}
