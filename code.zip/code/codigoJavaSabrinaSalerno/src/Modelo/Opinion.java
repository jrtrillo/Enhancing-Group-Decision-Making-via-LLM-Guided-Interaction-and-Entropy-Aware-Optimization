package Modelo;

import java.util.ArrayList;

public class Opinion {
	private float [][]opinion;
	private int filcolum;

	public Opinion(int num_alternativas){
		opinion = new float[num_alternativas][num_alternativas];
		filcolum = num_alternativas;
	}
	
	public Opinion(ArrayList<Float> valores, int alternativas){
		filcolum = alternativas;
		opinion = new float[alternativas][alternativas];

		for(int i = 0; i < alternativas; i++ ) {
			for(int j = 0; j < alternativas; j++ ) {
				if(i == j) {
					opinion[i][j] = 0;
					opinion[i][j] = 0;
				}
				else {
					opinion[i][j] = valores.get(0);
					valores.remove(0);
				}
			}
		}
	}

	public float calcularPreferenciaNeta(int alternativa) {
		float suma = 0;
		int n = filcolum;

		for (int j = 0; j < n; j++) {
			if (j != alternativa) {
				float fila = opinion[alternativa][j];  // cuánto prefiere alternativa sobre j
				float columna = opinion[j][alternativa]; // cuánto j prefiere sobre alternativa
				float valorcito = (fila - columna);
				if (valorcito > 0) {
					suma += (fila - columna);
				}
			}
		}

		return (suma / (n - 1)) * 100;
	}

	public int getFilcolum(){
		return filcolum;
	}

	public float[][] getOpinion(){
		return opinion;
	}

	public void getInfoOpinion(){
		for(int i = 0; i < this.getFilcolum(); i++){
			for(int j = 0; j < this.getFilcolum(); j++){
				if(i!=j)
					if(j == this.getFilcolum()-1){
						String a = String.valueOf(this.getOpinion()[i][j]);
						if(a.length()>4)
							System.out.print(String.valueOf(this.getOpinion()[i][j]).substring(0,5) + " \\\\ \t ");
						else
							System.out.print(String.valueOf(this.getOpinion()[i][j]).substring(0,3) + " \\\\ \t ");
					}
					else{
						String a = String.valueOf(this.getOpinion()[i][j]);
						if(a.length()>4)
							System.out.print(String.valueOf(this.getOpinion()[i][j]).substring(0,5) + " & \t ");
						else
							System.out.print(String.valueOf(this.getOpinion()[i][j]).substring(0,3) + " & \t ");
					}

				else
					if(j == this.getFilcolum()-1)
						System.out.print("- \t \\\\");
					else
						System.out.print("- & \t");
			}
			System.out.println();
		}
//		System.out.println();
	}


}
