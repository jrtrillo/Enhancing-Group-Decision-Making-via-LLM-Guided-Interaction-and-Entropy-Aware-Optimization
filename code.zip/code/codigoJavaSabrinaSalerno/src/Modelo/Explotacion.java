package Modelo;

import java.util.ArrayList;
import java.util.Collections;

public class Explotacion {
    private ArrayList<Float> valoresDeEleccionGDD;
    private ArrayList<Float> valoresDeEleccionGNDD;

    public Explotacion(){
        valoresDeEleccionGDD = new ArrayList<>();
        valoresDeEleccionGNDD = new ArrayList<>();
    }

    public void obtenerOrdenVector(ArrayList<Float> explotacion){
        ArrayList<Float> aux = new ArrayList<>();
        ArrayList<Integer> valoresIndices = new ArrayList<>();
        for(int i = 0; i < explotacion.size(); i++){
            aux.add(explotacion.get(i));
            valoresIndices.add(i);
        }

        for(int i = 0; i < aux.size(); i++){
            for(int j = 0; j < aux.size() - 1; j++){
                if(aux.get(i) > aux.get(j)){
                    float auxiliar = aux.get(i);
                    aux.set(i, aux.get(j));
                    aux.set(j, auxiliar);

                    int indice = valoresIndices.get(i);
                    valoresIndices.set(i, valoresIndices.get(j));
                    valoresIndices.set(j, indice);
                }
            }
        }
        System.out.println("El vector de indices es ");
        for(int i = 0; i < valoresIndices.size(); i++){
            System.out.print(valoresIndices.get(i) + ", ");
        }
        System.out.println();
    }
    public void funcionExplotacionGDD(Opinion criterio){
        float aux = 0;
        ArrayList<Float> arrayFinalExplotacion = new ArrayList<>();

        int tamanio = criterio.getFilcolum();
        ArrayList<ArrayList<Float>> auxCriterio = new ArrayList<>();
        ArrayList<Float> fila = new ArrayList<>();

        for(int i = 0; i < tamanio; i++){
            for(int j = 0; j < tamanio; j++){
                if(i != j)
                    fila.add(criterio.getOpinion()[i][j]);
            }
            auxCriterio.add(fila);
            fila = new ArrayList<>();
        }

        for(int i = 0; i < tamanio; i++){
            ArrayList<Float> arrayPesos = calcularPesos(tamanio-1);
            Collections.sort(auxCriterio.get(i));
            float suma = 0;
            for(int k = 0; k < arrayPesos.size(); k++){
                suma = (auxCriterio.get(i).get(k)*arrayPesos.get(k));
                aux+=suma;
            }
            arrayFinalExplotacion.add(aux);
            aux = 0;
        }
        valoresDeEleccionGDD = arrayFinalExplotacion;
    }

    ArrayList<Float> calcularPesos(int tam){
        ArrayList<Float> array_pesos = new ArrayList<>();
        float aux = 0;
        for(int i = 1; i < tam + 1; i++){
            float uno = ((float) i/tam);
            float dos = ((float) (i-1)/tam);

            aux = ((float) (Math.sqrt(uno) - Math.sqrt(dos)));
            array_pesos.add(aux);
        }
        return array_pesos;
    }

    public void funcionExplotacionGNDD(Opinion criterio){
        float aux = 0;
        ArrayList<Float> arrayFinalExplotacion = new ArrayList<>();
        int tamanio = criterio.getFilcolum();
        Opinion matriz_auxiliar = new Opinion(tamanio);
        float resta;
        for(int i = 0; i < tamanio; i++){
            for(int j = 0; j < tamanio; j++){
                if(i != j){
                    resta = criterio.getOpinion()[j][i] - criterio.getOpinion()[i][j];
                    if(resta > 0){
                        matriz_auxiliar.getOpinion()[i][j] = resta;
                    }
                    else{
                        matriz_auxiliar.getOpinion()[i][j] = 0;
                    }
                }
            }
        }
        for(int i = 0; i < tamanio; i++){
            for(int j = 0; j < tamanio; j++){
                if(i != j){
                    matriz_auxiliar.getOpinion()[i][j] = 1 - matriz_auxiliar.getOpinion()[i][j];
                }
            }
        }
        float criAux;
        ArrayList<Float> arrayAux = new ArrayList<>();
        ArrayList<Float> arrayPesos = calcularPesos(tamanio-1);
        for(int i = 0; i < tamanio; i++){
            for(int j = 0; j < tamanio; j++){
                if(i != j){
                    criAux = matriz_auxiliar.getOpinion()[i][j];
                    arrayAux.add(criAux);
                }
            }
            Collections.sort(arrayAux);
            for(int k = 0; k < arrayPesos.size(); k++){
                aux+=(arrayAux.get(k)*arrayPesos.get(k));
            }
            arrayAux = new ArrayList<>();
            arrayFinalExplotacion.add(aux);
            aux = 0;
        }
        this.valoresDeEleccionGNDD = arrayFinalExplotacion;
    }

    public void mostrarExplotacionGDD(){
        for(int i = 0; i<this.valoresDeEleccionGDD.size(); i++){
            if(valoresDeEleccionGDD.get(i).toString().length() < 4){
                System.out.print(valoresDeEleccionGDD.get(i).toString().substring(0,3) + " & ");
            }
            else{
                System.out.print(valoresDeEleccionGDD.get(i).toString().substring(0,4) + " & ");
            }
        }
        System.out.println();
    }

    public String explotacionGDDtoString(){
        String solucion = "Explotacion GDD \n";
        for(int i = 0; i<this.valoresDeEleccionGDD.size(); i++){
            if(valoresDeEleccionGDD.get(i).toString().length() < 4){
               solucion += valoresDeEleccionGDD.get(i).toString().substring(0,3) + " & ";
            }
            else{
                solucion +=  valoresDeEleccionGDD.get(i).toString().substring(0,4) + " & ";
            }
        }
        return solucion;
    }

    public void mostrarExplotacionGNDD(){
        for(int i = 0; i<this.valoresDeEleccionGNDD.size(); i++){
            if(valoresDeEleccionGNDD.get(i).toString().length() < 4){
                System.out.print(valoresDeEleccionGNDD.get(i).toString().substring(0,3) + " & ");
            }
            else{
                System.out.print(valoresDeEleccionGNDD.get(i).toString().substring(0,4) + " & ");
            }
        }
        System.out.println();
    }

    public String explotacionGNDDtoString(){
        String solucion = "Explotacion GNDD \n";
        for(int i = 0; i<this.valoresDeEleccionGNDD.size(); i++){
            if(valoresDeEleccionGNDD.get(i).toString().length() < 4){
                solucion += valoresDeEleccionGNDD.get(i).toString().substring(0,3) + " & ";
            }
            else{
                solucion += valoresDeEleccionGNDD.get(i).toString().substring(0,4) + " & ";
            }
        }
        return solucion;
    }

    public ArrayList<Float> getValoresDeEleccionGDD() {
        return valoresDeEleccionGDD;
    }

    public ArrayList<Float> getValoresDeEleccionGNDD() {
        return valoresDeEleccionGNDD;
    }
}
