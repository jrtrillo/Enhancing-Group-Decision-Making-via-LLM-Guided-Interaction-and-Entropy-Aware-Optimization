package Modelo;

import org.json.simple.JSONArray;
import java.util.*;

public class Agregacion {
    private Opinion matrizAgregadaOWA;
    private Opinion matrizAgregadaIOWA;
    private ArrayList<Float> arrayImportanciaCriterios;
    private ArrayList<Float> arrayImportanciaExpertos;

    Agregacion(int numAlternativas, JSONArray _pesosPorCriterio, ArrayList<Float> _pesosPorExperto){
        matrizAgregadaOWA = new Opinion(numAlternativas);
        matrizAgregadaIOWA = new Opinion(numAlternativas);
        arrayImportanciaCriterios = _pesosPorCriterio;
        arrayImportanciaExpertos = _pesosPorExperto;
    }

    //Función que calcula la agregación dado un conjunto de opiniones
    public void fun_agregacionOWA(ArrayList<ArrayList<Opinion>> opiniones){
        ArrayList<Opinion> array_aux = new ArrayList<>();
        ArrayList<Opinion> criteriosExpertos = new ArrayList<>();
        //Calculamos de forma individual la agregación para cada criterio, con sus pesos correspondientes
        Opinion aux;
        for(int i = 0; i < opiniones.get(0).size(); i++){
            for(int j = 0; j < opiniones.size(); j++){
                criteriosExpertos.add(opiniones.get(j).get(i));
            }
            aux = calcularMediaOWA(criteriosExpertos);
            array_aux.add(aux);
            criteriosExpertos = new ArrayList<>();
        }
        ArrayList<Opinion> array_final = new ArrayList<>();
        if(array_aux.size() != 1){
            aux = calcularMediaOWA(array_aux);
            array_final.add(aux);
        }
        else{
            array_final = array_aux;
        }
        this.matrizAgregadaOWA = array_final.get(0);

    }

    public Opinion calcularMediaOWA(ArrayList<Opinion> criterio){
        Opinion matriz_final = new Opinion(criterio.get(0).getFilcolum());
        float aux = 0;
        int tamanio = criterio.get(0).getFilcolum();
        ArrayList<Float> arrayAux = new ArrayList<>();
        for(int i = 0; i < tamanio; i++){
            for(int j = 0; j < tamanio; j++){
                if(i!=j){
                    for(int k = 0; k < criterio.size(); k++){
                        Opinion criAux = criterio.get(k);
                        arrayAux.add(criAux.getOpinion()[i][j]);
                    }
                    Comparator<Float> comparador = Collections.reverseOrder();
                    Collections.sort(arrayAux, comparador);
                    for(int k = 0; k < criterio.size(); k++){
                        aux += arrayAux.get(k);
                    }
                    aux = aux/arrayAux.size();
                }
                arrayAux = new ArrayList<>();
                matriz_final.getOpinion()[i][j] = aux;
                aux = 0;
            }
        }
        return  matriz_final;
    }



    ArrayList<Double> calcularPesos(int tam){
        ArrayList<Double> array_pesos = new ArrayList<>();
        double aux = 0;
        for(int i = 1; i < tam + 1; i++){
            float d1 = (float) i/tam;
            double v1 = Math.sqrt(d1);
            float d2 = (float) (i-1)/tam;
            double v2 = Math.sqrt(d2);

            aux = v1 - v2;
            array_pesos.add(aux);

        }
        return array_pesos;
    }

    //Función auxiliar que sirve para ordenar un array con respecto a otro valor
    // opiniones --> B
    // importanciaExpertos --> A
    ArrayList<Opinion> ordenarOpinionesImportancia(ArrayList<Opinion> opiniones, ArrayList<Float> arrayImportanciaExpertos){
        ArrayList<Opinion> opinionesFinal = new ArrayList<>();
        for(int i = 0; i < opiniones.size(); i++){
            opinionesFinal.add(opiniones.get(i));
        }

        for(int i = 0; i < arrayImportanciaExpertos.size(); i++){
            for(int j = 0; j < arrayImportanciaExpertos.size() - 1; j++){
                String c1s = String.valueOf(arrayImportanciaExpertos.get(j));
                float c1 = Float.valueOf(c1s);
                String c2s = String.valueOf(arrayImportanciaExpertos.get(j+1));
                float c2 = Float.valueOf(c2s);
                if(c1 < c2){
                    String c1actual = String.valueOf(arrayImportanciaExpertos.get(j));
                    float aux = Float.valueOf(c1actual);
                    String c2siguiente = String.valueOf(arrayImportanciaExpertos.get(j+1));
                    float siguiente = Float.valueOf(c2siguiente);

                    arrayImportanciaExpertos.set(j, siguiente);
                    arrayImportanciaExpertos.set(j+1, aux);

                    Opinion auxp = opinionesFinal.get(j);
                    opiniones.set(j, opinionesFinal.get(j+1));
                    opiniones.set(j+1, auxp);
                }
            }
        }
        return opinionesFinal;
    }


    public Opinion calcularMediaIOWA(ArrayList<Opinion> criterio){
        Opinion matriz_final = new Opinion(criterio.get(0).getFilcolum());
        float aux = 0;
        ArrayList<Float> arrayAux = new ArrayList<>();
        int tamanio = criterio.get(0).getFilcolum();
        ArrayList<Double> arrayPesos = calcularPesos(criterio.size());

        for(int i = 0; i < tamanio; i++){
            for(int j = 0; j < tamanio; j++){
                if(i != j){
                    for(int k = 0; k < criterio.size(); k++){
                        Opinion criAux = criterio.get(k);
                        arrayAux.add(criAux.getOpinion()[i][j]);
                    }
                    for(int k = 0; k < criterio.size(); k++){
                        aux += (arrayAux.get(k)*arrayPesos.get(k));
                    }
                }
                arrayAux = new ArrayList<>();
                matriz_final.getOpinion()[i][j] = aux;
                aux = 0;
            }
        }

        return matriz_final;
    }
    public ArrayList<ArrayList<Opinion>> obtenerOpinionesPorCriterio(ArrayList<ArrayList<Opinion>> opinionesProblema){
        ArrayList<ArrayList<Opinion>> opinionesCriterio = new ArrayList<>();
        ArrayList<Opinion> aux = new ArrayList<>();
        for(int i = 0; i < opinionesProblema.get(0).size(); i++){
            for(int j = 0; j < opinionesProblema.size(); j++){
                aux.add(opinionesProblema.get(j).get(i));
            }
            opinionesCriterio.add(aux);
            aux = new ArrayList<>();
        }

        return opinionesCriterio;
    }

    public void fun_agregacionIOWA(ArrayList<ArrayList<Opinion>> opiniones){
        ArrayList<ArrayList<Opinion>> opinionPorCriterio = obtenerOpinionesPorCriterio(opiniones);
        ArrayList<ArrayList<Opinion>> opinionesOrdenadas = new ArrayList<>();

        for(int i = 0; i < opinionPorCriterio.size(); i++){
            opinionesOrdenadas.add(ordenarOpinionesImportancia(opinionPorCriterio.get(i), arrayImportanciaExpertos));
        }

        ArrayList<Opinion> array_aux = new ArrayList<>();

        for(int i = 0; i < opinionesOrdenadas.size(); i++){
            Opinion aux = calcularMediaIOWA(opinionesOrdenadas.get(i));
            array_aux.add(aux);
        }

        Opinion opinionFinal;
        if(array_aux.size() != 1){
            ArrayList<Opinion> arrayPlus = ordenarOpinionesImportancia(array_aux, arrayImportanciaCriterios);
            opinionFinal = calcularMediaIOWA(arrayPlus);
        }
        else{
            opinionFinal = array_aux.get(0);
        }

        this.matrizAgregadaIOWA = opinionFinal;
    }

    void mostrarMatriz(Opinion op){
        for(int i = 0; i < op.getFilcolum(); i++){
            for(int j = 0; j < op.getFilcolum(); j++){
                System.out.print(op.getOpinion()[i][j] + " ");
            }
            System.out.println();
        }
    }

    public void mostrarAgregacionOWA(){
        for(int i = 0; i < this.matrizAgregadaOWA.getFilcolum(); i++){
            for(int j = 0; j < this.matrizAgregadaOWA.getFilcolum(); j++){
                if(this.matrizAgregadaOWA.getOpinion()[i][j] == 0){
                    System.out.print(" - & ");
                }
                else{
                    if(String.valueOf(this.matrizAgregadaOWA.getOpinion()[i][j]).length() > 4){
                        if(j == this.matrizAgregadaOWA.getFilcolum() - 1 )
                            System.out.print(String.valueOf(this.matrizAgregadaOWA.getOpinion()[i][j]).substring(0,4) + " \\\\ ");
                        else
                            System.out.print(String.valueOf(this.matrizAgregadaOWA.getOpinion()[i][j]).substring(0,4) + " & ");
                    }
                    else{
                        if(j == this.matrizAgregadaOWA.getFilcolum() - 1 )
                            System.out.print(String.valueOf(this.matrizAgregadaOWA.getOpinion()[i][j]).substring(0,3) + " \\\\ ");
                        else
                            System.out.print(String.valueOf(this.matrizAgregadaOWA.getOpinion()[i][j]).substring(0,3) + " \\\\ ");
                    }
                }
            }
            System.out.println();
        }
    }

    public void mostrarAgregacionIOWA(){
        for(int i = 0; i < this.matrizAgregadaIOWA.getFilcolum(); i++){
            for(int j = 0; j < this.matrizAgregadaIOWA.getFilcolum(); j++){
                if(this.matrizAgregadaIOWA.getOpinion()[i][j] == 0){
                    System.out.print(" - & ");
                }
                else{
                    if(String.valueOf(this.matrizAgregadaIOWA.getOpinion()[i][j]).length() > 4){
                        if(j == this.matrizAgregadaIOWA.getFilcolum() - 1 )
                            System.out.print(String.valueOf(this.matrizAgregadaIOWA.getOpinion()[i][j]).substring(0,4) + " \\\\ ");
                        else
                            System.out.print(String.valueOf(this.matrizAgregadaIOWA.getOpinion()[i][j]).substring(0,4) + " & ");
                    }
                    else{
                        if(j == this.matrizAgregadaIOWA.getFilcolum() - 1 )
                            System.out.print(String.valueOf(this.matrizAgregadaIOWA.getOpinion()[i][j]).substring(0,3) + " \\\\ ");
                        else
                            System.out.print(String.valueOf(this.matrizAgregadaIOWA.getOpinion()[i][j]).substring(0,3) + " \\\\ ");
                    }
                }
            }
            System.out.println();
        }
    }

    public Opinion getAgregacionOWA(){
        return matrizAgregadaOWA;
    }
    public Opinion getAgregacionIOWA(){
        return matrizAgregadaIOWA;
    }



}
