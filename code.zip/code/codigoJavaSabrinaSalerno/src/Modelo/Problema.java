package Modelo;
import org.json.JSONTokener;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

public class Problema {
	private int alternativas;
	private int criterios;
	private String nombre;

	private ArrayList<Integer> sociomatriz;

	private ArrayList<Experto> expertos;
	private ArrayList< ArrayList<Opinion>> conjuntoOpiniones;

	private Consistencia consistencia;
	private Consenso consenso;

	private Agregacion agregacion;
	private Explotacion explotacionOWA;
	private Explotacion explotacionIOWA;

	private double alpha;
	private double gamma;

	public Problema(String ruta, int problema, double _alpha, double _beta){
		consistencia = new Consistencia();
		consenso = new Consenso();
		expertos = new ArrayList<>();
		conjuntoOpiniones = new ArrayList<>();
		alpha = _alpha;
		gamma = _beta;

		JSONParser parser = new JSONParser();

		try{
			Object obj = parser.parse(new FileReader(ruta));
			JSONObject jsonObject = (JSONObject) obj;
			JSONArray array = (JSONArray) jsonObject.get("Problemas");
			JSONObject jsonObjectObtenido = (JSONObject) array.get(problema);

			//Se define el nombre del problema
			this.nombre = (String) jsonObjectObtenido.get("nombre");

			//Se define el numero de criterios
			this.criterios = Integer.parseInt(jsonObjectObtenido.get("numCriterios").toString());

			//Se define el numero de alternativas
			this.alternativas = Integer.parseInt(jsonObjectObtenido.get("numAlternativas").toString());

			//Se define el numero de expertos
			JSONArray arrayExpertos = (JSONArray)jsonObjectObtenido.get("expertos");
			int numExpertos = arrayExpertos.size();

			JSONArray pesosPorCriterios = new JSONArray();
			for(int i = 0; i < numExpertos; i++){
				JSONObject expertoJson = (JSONObject) arrayExpertos.get(i);
				pesosPorCriterios = (JSONArray)expertoJson.get("pesoCriterios");
				JSONArray valoresOpinion = (JSONArray) expertoJson.get("opinion");
				float pesoExperto = Float.parseFloat(expertoJson.get("pesoProblema").toString());
				String nom = expertoJson.get("nombre").toString();

				Experto aux = new Experto(pesosPorCriterios,pesoExperto,valoresOpinion,alternativas,criterios, nom);
				expertos.add(aux);
			}

			ArrayList<Opinion> aux = new ArrayList<>();
			for(int i = 0; i < this.getExpertos().size(); i++){
				for(int j = 0; j <this.getExperto(i).getOpiniones().size();j++){
					aux.add(this.getExperto(i).getOpinion(j));
				}
				this.conjuntoOpiniones.add(aux);
				aux = new ArrayList<>();
			}

			this.calcularConsistencia();
			this.calcularConsenso();

			ArrayList<Float> pesosPorExpertos = new ArrayList<>();
			for(int i = 0; i < expertos.size(); i++){
				pesosPorExpertos.add(this.getExperto(i).getPesoExperto());
			}

			agregacion = new Agregacion(alternativas, pesosPorCriterios, pesosPorExpertos);
			this.calcularAgregacion();
			explotacionOWA = new Explotacion();
			this.calcularExplotacionOWA();

			agregacion = new Agregacion(alternativas, pesosPorCriterios, pesosPorExpertos);
			this.calcularAgregacion();
			explotacionIOWA = new Explotacion();
			this.calcularExplotacionIOWA();

		}catch(FileNotFoundException e){
			System.out.println("Archivo no encontrado " + e);
		}
		catch(IOException e){
			System.out.println("IOException " + e);
		}
		catch(ParseException e){
			System.out.println("ParseException " + e);
		}
    }

	public void mostrarOpiniones(){
		for(int i = 0; i < this.getNumExpertos(); i++){
//			System.out.println("Experto " + i);
			for(int j = 0; j < this.getCriterios(); j++){
				System.out.println("PC^{" + (i+1) + "" + (j+1)+"} = ");
				System.out.println("\\begin{bmatrix}");
				for(int x = 0; x < this.getAlternativas(); x++){
					for(int y = 0; y < this.getAlternativas(); y++){
						if(x != y){
							String aux = String.valueOf(conjuntoOpiniones.get(i).get(j).getOpinion()[x][y]);
							if(aux.length() == 3)
								System.out.print(aux.substring(0,3) + "\t & ");
							else
								System.out.print(aux.substring(0,4) + "\t & ");
						}
						else{
							System.out.print("- \t & ");
						}
					}
					System.out.print(" \\\\");
					System.out.println();
				}
//				System.out.println();
			}
			System.out.println("\\end{bmatrix}");
			if(i==1)
				System.out.print("$$\n$$\n");
//			System.out.println();
		}
	}

	public void mostrarOpinionesVectorizado(){
		for(int i = 0; i < this.getNumExpertos(); i++){
			for(int j = 0; j < this.getCriterios(); j++){
				for(int x = 0; x < this.getAlternativas(); x++){
					for(int y = 0; y < this.getAlternativas(); y++){
						if(x != y){
							String aux = String.valueOf(conjuntoOpiniones.get(i).get(j).getOpinion()[x][y]);
							if(aux.length() == 3)
								System.out.print(aux.substring(0,3) + ",");
							else
								System.out.print(aux.substring(0,4) + ",");
						}
					}
				}
				System.out.println();
			}
		}
	}

	public void setValorOpinion(int experto, int criterio, int x, int y, float valor){
		conjuntoOpiniones.get(experto).get(criterio).getOpinion()[x][y] = valor;
	}

	public Experto getExperto(int indice) {
		return expertos.get(indice);
	}

	public ArrayList<Experto> getExpertos(){
		return expertos;
	}

	public int getAlternativas() {
		return alternativas;
	}

	public int getCriterios() {
		return criterios;
	}

	public String getNombre() {
		return nombre;
	}

	public Consistencia getConsistencia(){
		return  consistencia;
	}

	public void setAlternativas(int alternativas) {
		this.alternativas = alternativas;
	}

	public void setCriterios(int criterios) {
		this.criterios = criterios;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setExpertos(ArrayList<Experto> expertos) {
		this.expertos = expertos;
	}

	public ArrayList<ArrayList<Opinion>> getOpiniones() {
		return conjuntoOpiniones;
	}

	public void setOpiniones(ArrayList<ArrayList<Opinion>> opiniones) {
		this.conjuntoOpiniones = opiniones;
	}

	public void setNivelConsistencia(Consistencia nivelConsistencia) {
		this.consistencia = nivelConsistencia;
	}

	public Consenso getConsenso() {
		return consenso;
	}

	public void setNivelConsenso(Consenso nivelConsenso) {
		this.consenso = nivelConsenso;
	}

	public void calcularConsistencia(){
		ArrayList<Float> pesos = new ArrayList<>();
		for(int i = 0; i < this.getNumExpertos(); i++){
			for(int j = 0; j < this.getExperto(i).getPesosCriterios().size(); j++){
				pesos.add(this.getExperto(i).getPesosCriterios().get(j));
			}
		}
		consistencia.funcionNivelConsistencia(this.conjuntoOpiniones, this.getExpertos().size(), this.getAlternativas(), pesos);
	}

	public void calcularConsenso(){
		consenso.funcionNivelConsenso(this.conjuntoOpiniones, this.getExpertos().size(), this.getCriterios());
	}

	public void calcularAgregacion(){
		agregacion.fun_agregacionOWA(conjuntoOpiniones);
		agregacion.fun_agregacionIOWA(conjuntoOpiniones);
	}

	public void calcularExplotacionOWA(){
		explotacionOWA.funcionExplotacionGDD(agregacion.getAgregacionOWA());
		explotacionOWA.funcionExplotacionGNDD(agregacion.getAgregacionOWA());
	}

	public void calcularExplotacionIOWA(){
		explotacionIOWA.funcionExplotacionGDD(agregacion.getAgregacionIOWA());
		explotacionIOWA.funcionExplotacionGNDD(agregacion.getAgregacionIOWA());
	}

	public Agregacion getAgregacion(){
		return this.agregacion;
	}

	public Explotacion getExplotacionOWA(){
		return this.explotacionOWA;
	}
	public Explotacion getExplotacionIOWA(){
		return this.explotacionIOWA;
	}

	public void getInfo(){
		System.out.println("Los datos para el problema \"" + this.getNombre() + "\" son: ");
		System.out.println("Las consistencias para los expertos son: ");
		float c = (float) (this.getConsistencia().getNivelConsistencia()*0.5 + this.getConsenso().getNivelConsenso()*0.5);
//		float c = (float) (this.getConsistencia().getNivelConsistencia()*0.5 + this.getConsistencia().getNivelConsistencia()*0.5);

		System.out.println("\\begin{itemize}");
		System.out.println("\t\\item Q: " + c);
		System.out.println("\t\\item Q1: " + this.getConsistencia().getNivelConsistencia());
		System.out.println("\\begin{itemize}");
		for(int i = 0; i < this.getExpertos().size(); i++){
//			System.out.println("\tPara el Experto " + this.getExperto(i).getNombre() + " = " + this.getConsistencia().getNivelesConsistenciaExpertos().get(i));
			System.out.println("\t\t\\item Experto " + i + ": " + this.getConsistencia().getNivelesConsistenciaExpertos().get(i));
		}
		System.out.println("\t\\end{itemize}");
		System.out.println("\t\\item Q2: " + this.getConsenso().getNivelConsenso());
		System.out.println("\\end{itemize}");

//		System.out.println("El valor global de la consistencia es " + this.getConsistencia().getNivelConsistencia());
//		System.out.println("El valor global del consenso es " + this.getConsenso().getNivelConsenso());

//		System.out.println();
//		System.out.println("La matriz agregada (OWA) para el problema es la siguiente:");
//		this.getAgregacion().mostrarAgregacionOWA();
//		System.out.println("La matriz agregada (IOWA) para el problema es la siguiente:");
//		this.getAgregacion().mostrarAgregacionIOWA();
//
//		System.out.println();
//		System.out.println("La explotación (GDD) sobre la matriz (OWA) es: ");
//		this.getExplotacionOWA().mostrarExplotacionGDD();
//		// this.getExplotacionOWA().obtenerOrdenVector(this.getExplotacionOWA().getValoresDeEleccionGDD());
//		System.out.println();
//		System.out.println("La explotación (GNDD) sobre la matriz (OWA) es: ");
//		this.getExplotacionOWA().mostrarExplotacionGNDD();
//		// this.getExplotacionOWA().obtenerOrdenVector(this.getExplotacionOWA().getValoresDeEleccionGNDD());
//
//		System.out.println();
//		System.out.println();
//		System.out.println("La explotación (GDD) sobre la matriz (IOWA) es: ");
//		this.getExplotacionIOWA().mostrarExplotacionGDD();
//		// this.getExplotacionIOWA().obtenerOrdenVector(this.getExplotacionIOWA().getValoresDeEleccionGDD());
//		System.out.println();
//		System.out.println("La explotación (GNDD) sobre la matriz (IOWA) es: ");
//		this.getExplotacionIOWA().mostrarExplotacionGNDD();
//		// this.getExplotacionIOWA().obtenerOrdenVector(this.getExplotacionIOWA().getValoresDeEleccionGNDD());

	}

	public void obtenerStringOpiniones(){
		for(int i = 0; i < this.getExpertos().size(); i++){
			System.out.println("Experto " + i);
			for(int j = 0; j < this.getCriterios(); j++){
				System.out.println("Criterio " + j);
				this.getExpertos().get(i).getOpiniones().get(j).getInfoOpinion();
			}
		}
	}

	public void mostrarOpiniones(ArrayList<ArrayList<Opinion>> opiniones){
		for(int i = 0; i < opiniones.size();i++){
			for(int j = 0; j < opiniones.get(i).size(); j++){
				for(int x = 0; x < opiniones.get(i).get(j).getFilcolum(); x++){
					for(int y = 0; y < opiniones.get(i).get(j).getFilcolum(); y++){
						if(x!=y)
							System.out.print(String.valueOf(opiniones.get(i).get(j).getOpinion()[x][y]).substring(0,4) + "\t");
						else
							System.out.print("- \t");
					}
					System.out.println();
				}
				System.out.println();
			}
			System.out.println();
		}
	}

	public int getNumExpertos(){
		return this.expertos.size();
	}
}
