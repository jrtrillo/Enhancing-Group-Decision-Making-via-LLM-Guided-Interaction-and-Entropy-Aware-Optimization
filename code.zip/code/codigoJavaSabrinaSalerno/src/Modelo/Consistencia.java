package Modelo;


import java.util.ArrayList;

public class Consistencia {

	private float nivelConsistencia;
	private ArrayList<Float> nivelesConsistenciaExpertos;

	public Consistencia(){
		this.nivelConsistencia = 0f;
	}

	public float nivelConsistenciaMatriz(float[][] p) {
		float [][] m_aux = new float [p.length][p.length];

		for(int x = 0; x < p.length; x++) {
			for(int z = 0; z < p.length; z++) {
				//Inicializamos las variables que van a intervenir en el proceso
				float cpj1 = 0;
				float cpj2 = 0;
				float cpj3 = 0;
				float cp;
				float epsip;
				float cl;

	            //Obtenemos la parte 3, 4 y 5
	            for(int i = 0; i < p.length; i++) {
	            	for(int j = 0; j < p.length; j++) {
	            		for(int k = 0; k < p.length; k++) {
							if(i != k && i!=j && k!= j && i==x && k==z){
								cpj1 += (p[i][j])+(p[j][k])-(0.5);
								cpj2 += (p[j][k])-(p[j][i])+(0.5);
								cpj3 += (p[i][j])-(p[k][j])+(0.5);
							}
	    	            }
		            }
	            }

	            //Parte 6
	            if(p.length != 2)
	                cp=((cpj1+cpj2+cpj3)/(3*(p.length-2)));
	            else
	                cp=((cpj1+cpj2+cpj3)/(3));

	            //Parte 7
	            epsip=(2*(Math.abs(cp-(p[x][z]))))/3;
	            //Parte 8
	            cl=(1-epsip);

	            if(x==z)
	                m_aux[x][z]=0;
	            else
	                m_aux[x][z]=cl;
			}
		}

		ArrayList<Float> array_aux = new ArrayList<>();

		float suma;

		//Parte 9
		for(int i = 0; i < p.length; i++) {
	        suma=0;
	        for(int k = 0; k < p.length; k++)
	            suma+=m_aux[i][k]+m_aux[k][i];
	        array_aux.add(suma/(2*(p.length-1)));
		}


		//Parte 10
		suma=0;
		for(int i = 0; i < array_aux.size(); i++)
		   suma+=array_aux.get(i);
		return suma/array_aux.size();
	}


	public float obtenerConsistenciaExpertoModificada(ArrayList<Opinion> arrayMatricesExperto, ArrayList<Float> pesos, int alternativas) {
		float suma, consistenciaFinal = 0;
		for(int i = 0; i < arrayMatricesExperto.size(); i++){
			suma = nivelConsistenciaMatriz(arrayMatricesExperto.get(i).getOpinion());
//			System.out.println("Para el criterio " + i + " vale " + suma);
			suma = suma * pesos.get(i);
			consistenciaFinal += suma;
		}

		return consistenciaFinal;
	}

	public float funcionNivelConsistencia(ArrayList<ArrayList<Opinion>> opiniones, int numExpertos, int numAlternativas, ArrayList<Float> pesos) {
		float aux = 0;
		float auxindi;
		nivelesConsistenciaExpertos = new ArrayList<>();

		for(int i = 0; i < numExpertos; i++) {
			auxindi=obtenerConsistenciaExpertoModificada(opiniones.get(i), pesos, numAlternativas);
//			System.out.println("La consistencia vale " + auxindi);
			aux+=auxindi;
			nivelesConsistenciaExpertos.add(auxindi);
		}
		nivelConsistencia=(aux/numExpertos);

		return nivelConsistencia;
	}

	public void setNivelConsistencia(float nivelConsistencia) {
		this.nivelConsistencia = nivelConsistencia;
	}

	public float getNivelConsistencia(){
		return nivelConsistencia;
	}

	public ArrayList<Float> getNivelesConsistenciaExpertos() {
		return nivelesConsistenciaExpertos;
	}
}
