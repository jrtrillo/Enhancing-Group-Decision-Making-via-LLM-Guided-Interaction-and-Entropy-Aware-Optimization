package Modelo;

import org.json.simple.JSONArray;

import java.util.ArrayList;

public class Experto {
	private float pesoExperto;
	private ArrayList<Float> pesosPorCriterio = new ArrayList<>();
	private ArrayList<Opinion> opiniones = new ArrayList<>();
	private float nivelConsistencia;
	private String nombre;

	private ArrayList<Opinion> sociomatriz = new ArrayList<>();

	// BlockChain
	private int voluntadCambio = 1;
	private double confianzaGrupo = 0.7;
	private double problemasInternos = 1;
	private double problemasExternos = 1;

	public Experto(JSONArray pesosCriterios, float pesoExpertoProblema, JSONArray opinionArray, int numAlternativas, int numCriterios, String n){
		for(int i = 0; i < pesosCriterios.size(); i++){
			pesosPorCriterio.add(Float.parseFloat((pesosCriterios.get(i).toString())));
		}
		this.nombre = n;
		pesoExperto = pesoExpertoProblema;

		Opinion op;
		ArrayList<Float> aux = new ArrayList<>();

		for(int i = 0; i < opinionArray.size(); i++){
			aux.add(Float.parseFloat(opinionArray.get(i).toString()));
		}
		for(int i = 0; i < numCriterios; i++) {
			op = new Opinion(aux, numAlternativas);
			opiniones.add(op);
		}

	}

	public Opinion getOpinion(int indice){
		return opiniones.get(indice);
	}
	public ArrayList<Opinion> getOpiniones(){
		return opiniones;
	}
	public float getPesoExperto() {
		return pesoExperto;
	}
	public float getPesoPorCriterio(int indice){
		return pesosPorCriterio.get(indice);
	}
	public ArrayList<Float> getPesosCriterios(){
		return pesosPorCriterio;
	}
	public float getNivelConsistencia(){
		return nivelConsistencia;
	}
	public void setNivelConsistencia(float valor){this.nivelConsistencia = valor;}

	public void getInfoExperto(){
		System.out.println("Esta es la info de " + this.nombre);
		System.out.println("Su peso en el problema es " + this.getPesoExperto());
		System.out.println("Los pesos por cada criterio son ");
		for(int i = 0; i < this.getPesosCriterios().size(); i++){
			System.out.print(this.getPesoPorCriterio(i) + " ");
		}
		System.out.println();
		System.out.println("Su opinion es ");
		for(int i = 0; i < this.getOpiniones().size(); i++){
			this.getOpinion(i).getInfoOpinion();
		}
		System.out.println();
	}

	public void modificarConfianzaGrupo(double valor){
		this.confianzaGrupo = valor;
	}
	public String getNombre(){
		return nombre;
	}

	public int getVoluntadCambio() {
		return voluntadCambio;
	}

	public void setVoluntadCambio(int voluntadCambio) {
		this.voluntadCambio = voluntadCambio;
	}

	public double getConfianzaGrupo() {
		return confianzaGrupo;
	}

	public void setConfianzaGrupo(double confianzaGrupo) {
		this.confianzaGrupo = confianzaGrupo;
	}

	public double getProblemasInternos() {
		return problemasInternos;
	}

	public void setProblemasInternos(double problemasInternos) {
		this.problemasInternos = problemasInternos;
	}

	public double getProblemasExternos() {
		return problemasExternos;
	}

	public void setProblemasExternos(double problemasExternos) {
		this.problemasExternos = problemasExternos;
	}
}
