package Modelo;

import Algoritmo.Algoritmo;
import org.json.JSONTokener;

import java.util.ArrayList;

public class Consenso {
    private float nivelConsenso;


    public Consenso(){
        nivelConsenso = 0;
    }

    public double funcionNivelConsenso(ArrayList<ArrayList<Opinion>> opiniones, int numExpertos, int numCriterios){
        float suma=0;
        ArrayList<ArrayList<Opinion>> opinionesPorCriterio = obtenerOpinionesPorCriterio(opiniones);

        for(int i = 0; i < opinionesPorCriterio.size(); i++){
            float sux = nivelConsensoCriterio(opinionesPorCriterio.get(i), numExpertos);
            suma+=sux;
        }

        float clFinal = suma/numCriterios;

        this.nivelConsenso = clFinal;

        return nivelConsenso;
    }


    public ArrayList<ArrayList<Opinion>> obtenerOpinionesPorCriterio(ArrayList<ArrayList<Opinion>> opinionesProblema){
        ArrayList<ArrayList<Opinion>> opinionesCriterio = new ArrayList<>();
        ArrayList<Opinion> aux = new ArrayList<>();

        for(int i = 0; i < opinionesProblema.get(0).size(); i++){
            for(int j = 0; j < opinionesProblema.size(); j++){
                aux.add(opinionesProblema.get(j).get(i));
            }
            opinionesCriterio.add(aux);
            aux = new ArrayList<>();
        }
        return opinionesCriterio;
    }

    //Funcion que calcula la consistencia de un experto dado
    public float nivelConsensoCriterio(ArrayList<Opinion> opinionesCriterio, int num_expertos){
        //Parte 9
        ArrayList<Opinion> opiniones_criterios_calculadas=calculoMatricesParte9(opinionesCriterio);

        //Parte 10
        Opinion m_final = sumaMatricesyNormalizacionParte10(opiniones_criterios_calculadas, num_expertos);

        //Partes 11 y 12
        ArrayList<Float> array_aux=obtenerVectorPesosParte11y12(m_final);

        //Parte 13
        float ckr = obtenerConsensoFinal(array_aux);

        return ckr;

    }

    public ArrayList<Opinion> calculoMatricesParte9(ArrayList<Opinion> arraymatrices){
        ArrayList<Opinion> array_aux = new ArrayList<>();
        Opinion aux = arraymatrices.get(0);
        Opinion m_aux = new Opinion(aux.getFilcolum());

        //Parte 9
        //Obtengo todas las matrices de similaridad
        if(arraymatrices.size() == 1){
            arraymatrices.add(arraymatrices.get(0));
        }
        else{
            for(int i = 0; i < arraymatrices.size(); i++){
                Opinion m1 = arraymatrices.get(i);
                for(int j = i; j < arraymatrices.size(); j++){
                    Opinion m2 = arraymatrices.get(j);
                    if(i!=j){
                        for(int x = 0; x < m1.getFilcolum(); x++){
                            for(int y = 0; y < m2.getFilcolum(); y++){
                                if(x!=y){
                                    m_aux.getOpinion()[x][y] = 1 - ( Math.abs( m1.getOpinion()[x][y] - m2.getOpinion()[x][y] ) );
                                }
                            }
                        }
                        array_aux.add(m_aux);
                        m_aux = new Opinion(aux.getFilcolum());
                    }
                }
            }
        }
        return array_aux;
    }


    public Opinion sumaMatricesyNormalizacionParte10(ArrayList<Opinion> array_aux, int num_expertos){
        //Obtención de la matriz final, y normalización
        Opinion aux = array_aux.get(0);
        Opinion mFinal = new Opinion(aux.getFilcolum());
        Opinion m_aux = new Opinion(aux.getFilcolum());
        if(array_aux.size() == 1){
            for(int i = 0; i < aux.getFilcolum(); i++){
                for(int j = 0; j < aux.getFilcolum(); j++){
                    if(i!=j){
                        if(num_expertos==1){
                            m_aux.getOpinion()[i][j] = array_aux.get(0).getOpinion()[i][j]/2;
                        }
                        else{
                            m_aux.getOpinion()[i][j] = (float) ((array_aux.get(0).getOpinion()[i][j])/((num_expertos-1)*num_expertos*0.5));
                        }
                    }
                }
            }
            return m_aux;
        }
        else{
            for(int i = 0; i < array_aux.size(); i++){
                mFinal = sumaMatrices(mFinal, array_aux.get(i));
            }

            for(int i = 0; i < mFinal.getFilcolum(); i++){
                for(int j = 0; j < mFinal.getFilcolum(); j++){
                    if(i!=j){
                        if(num_expertos==1){
                            m_aux.getOpinion()[i][j] = mFinal.getOpinion()[i][j]/2;
                        }
                        else{
                            int div = ((num_expertos-1)*num_expertos)/2;
                            m_aux.getOpinion()[i][j] = (float) ((mFinal.getOpinion()[i][j])/div);
                        }
                    }
                }
            }
            return m_aux;
        }
    }

    public Opinion sumaMatrices(Opinion aux, Opinion m){
        for(int i = 0; i <aux.getFilcolum(); i++){
            for(int j = 0; j <aux.getFilcolum(); j++){
                aux.getOpinion()[i][j] = aux.getOpinion()[i][j] + m.getOpinion()[i][j];
            }
        }
        return aux;
    }

    public ArrayList<Float> obtenerVectorPesosParte11y12(Opinion mFinal){
        ArrayList<Float> arrayaux=new ArrayList<Float>();

        for(int i = 0; i < mFinal.getFilcolum(); i++){
            float suma = 0;
            for(int j = 0; j < mFinal.getFilcolum(); j++){
                if(i!=j){
                    float s = mFinal.getOpinion()[i][j] + mFinal.getOpinion()[j][i];
                    suma += s;
                }
            }
            float ca = suma/(2*(mFinal.getFilcolum()-1));
            arrayaux.add(ca);
        }
        return arrayaux;
    }

    public float obtenerConsensoFinal(ArrayList<Float> array_aux){
        float suma = 0;
        for(int i = 0; i < array_aux.size(); i++){
            suma += array_aux.get(i);
        }
        float crk = suma / array_aux.size();
        return  crk;
    }

    public float getNivelConsenso(){
        return nivelConsenso;
    }

    public void setNivelConsenso(float nivelConsenso) {
        this.nivelConsenso = nivelConsenso;
    }
}

