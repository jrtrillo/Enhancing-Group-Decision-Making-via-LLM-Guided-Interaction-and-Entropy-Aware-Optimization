from transformers import AutoTokenizer, AutoModelForCausalLM
from huggingface_hub import login
import torch

# Autenticación en Hugging Face
login("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")

# Configuración del modelo
model_id = "mistralai/Mistral-7B-Instruct-v0.1"
tokenizer = AutoTokenizer.from_pretrained(model_id, token="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")
model = AutoModelForCausalLM.from_pretrained(
    model_id,
    token="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",
    torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
    device_map="auto"
)

# === FASE 1: Prompt y ejecución ===
def build_prompt(alternativa_correcta, experto, tema):
    prompt = (
            f"You are a debate moderator whose goal is to persuade {experto} to seriously consider the alternative {alternativa_correcta} in the context of the {tema} debate.\n"
	        f"Begin by briefly acknowledging {experto}'s experience and perspective on {tema}.\n"
            f"Present 2 or 3 strong, specific arguments highlighting why {alternativa_correcta} is a valuable and distinctive {tema} choice, emphasizing its cultural, historical, experiential, or practical benefits.\n"
	        f"Include at least 2 thought-provoking questions tailored to {alternativa_correcta} that invite {experto} to reflect on its unique appeal and how it might enrich the {tema} experience differently from other.\n"
            f"Write one clear, concise, and persuasive paragraph."
        )
    return prompt

def run_mistral(prompt):
    inputs = tokenizer(prompt, return_tensors="pt", truncation=True)
    inputs = {k: v.to(model.device) for k, v in inputs.items()}

    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            max_new_tokens=300,
            do_sample=True,
            temperature=0.7,
            top_p=0.9,
            pad_token_id=tokenizer.eos_token_id
        )

    result = tokenizer.decode(outputs[0], skip_special_tokens=True)
    return result


prompt = build_prompt("Football", "Alonso", "Sports")
result = run_mistral(prompt)

print("\n=== Mistral Response ===\n")

if not result.strip():
    print("⚠️ No response generated. Please check your prompt or system resources.")
    exit()
else:
    print(result)