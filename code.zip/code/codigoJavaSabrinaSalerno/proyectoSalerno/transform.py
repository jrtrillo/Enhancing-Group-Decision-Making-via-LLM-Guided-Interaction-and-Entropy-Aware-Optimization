from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline
from huggingface_hub import login
import torch

# 1. Login en Hugging Face
token = "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"
login(token)

model_id = "mistralai/Mistral-7B-Instruct-v0.1"

print("Loading tokenizer...")
tokenizer = AutoTokenizer.from_pretrained(
    model_id,
    use_auth_token=token
)

# 2. Intento de quantización 8-bit + offload + low_cpu_mem_usage
print("Trying 8-bit quantization with bitsandbytes…")
try:
    model = AutoModelForCausalLM.from_pretrained(
        model_id,
        use_auth_token=token,
        load_in_8bit=True,            # quantización 8-bit
        device_map="auto",            # reparte capas en GPU/CPU
        offload_folder="offload_dir",  # carpeta local para offload
        offload_state_dict=True,       # offload de estados de optimizador
        low_cpu_mem_usage=True         # inicialización ligera
    )
    print("✅ 8-bit quantization successful!")
except Exception as e:
    print(f"⚠️ 8-bit quantization failed: {e}")
    print("Falling back to CPU dynamic quantization…")

    # 2a. Carga ligera en CPU
    model = AutoModelForCausalLM.from_pretrained(
        model_id,
        use_auth_token=token,
        device_map="cpu",            # todo en CPU
        torch_dtype=torch.float32,   # float32 requerido por quantize_dynamic
        low_cpu_mem_usage=True
    )
    # 2b. Dynamic quantization de los Linear
    model = torch.quantization.quantize_dynamic(
        model, 
        {torch.nn.Linear}, 
        dtype=torch.qint8          # int8 en capas lineales
    )
    print("✅ Dynamic quantization applied!")

# 3. Pipeline
print("Creating pipeline…")
pipe = pipeline(
    "text-generation",
    model=model,
    tokenizer=tokenizer
)

def build_prompt(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        preferences = f.read()
    if not preferences.strip():
        print("Warning: preferences.txt está vacío")
    prompt = (
        "You are an AI that analyzes expert preferences.\n"
        "Given the following pairwise comparisons from different experts, "
        "determine which alternative is the best overall and which expert prefer that alternative:\n\n"
        "IMPORTANT: You should note that users prefer an alternative if they have a 60% or more"
        f"{preferences}\n\n"
        "Your answer must start with: 'The best alternative is Alternative X'\n"
        "Then provide a second sentence listing the experts who chose that alternative in this exact format:\n"
        "'The experts who decided on Alternative X are Expert Y and Expert Z.'\n"
    )
    return prompt

def run_mistral(prompt):
    print("Generating response…")
    output = pipe(
        prompt,
        max_new_tokens=400,   # mismos parámetros tuyos
        do_sample=True,
        temperature=0.7,
        top_p=0.9,
        return_full_text=False
    )
    print("Output raw:", output)
    return output[0]['generated_text']

if __name__ == "__main__":
    prompt = build_prompt(r"C:\Users\quesa\Desktop\UGR\proyectoSalerno\preferences.txt")
    print("Prompt:\n", prompt)
    result = run_mistral(prompt)
    print("\n=== Mistral Response ===\n")
    print(result)