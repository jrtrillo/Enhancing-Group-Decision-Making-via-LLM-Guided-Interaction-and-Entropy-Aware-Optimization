from transformers import AutoTokenizer, AutoModelForCausalLM
from huggingface_hub import login
import torch
import re
import json

# ————— Autenticación en Hugging Face —————
login("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")

# ————— Configuración del modelo —————
model_id = "mistralai/Mistral-7B-Instruct-v0.1"
tokenizer = AutoTokenizer.from_pretrained(model_id, token="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")
model = AutoModelForCausalLM.from_pretrained(
    model_id,
    token="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",
    torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
    device_map="auto",
    offload_folder="./offload"
)

# ————— Construcción del prompt —————
def build_prompt(file_path: str) -> str:
    with open(file_path, "r", encoding="utf-8") as f:
        data = json.load(f)          # lee el JSON como dict

    if not data:                     # dict vacío
        print("Warning: preferences.json está vacío")
        return ""
    
    rp1 = str(data["RP1"])
    rp2 = str(data["RP2"])
    rp3 = str(data["RP3"])
    rp4 = str(data["RP4"])

    prompt = (
        "You are an AI that analyzes fuzzy preference data from multiple decision-makers.\n"
        "Each matrix below represents how one decision-maker (DM) evaluates four alternatives:\n"
        "- a1: Alt1\n"
        "- a2: Alt2\n"
        "- a3: Alt3\n"
        "- a4: Alt4\n\n"
        "Each matrix shows the degree to which the row alternative is preferred over the column alternative.\n"
        "Values range from 0 to 1:\n"
        "- 1.0 = the row alternative is completely preferred over the column.\n"
        "- 0.5 = indifference.\n"
        "- 0.0 = the column alternative is completely preferred over the row.\n"
        "- Intermediate values express partial preferences.\n"
        "Note: the matrices are asymmetric. For example:\n"
        "- A value of 0.7 in cell (a1, a2) means the decision-maker prefers a1 over a2 with intensity 0.7.\n"
        "- A value of 0.3 in cell (a2, a1) means the same thing: since a1 is preferred over a2 with 0.7, then a2 is preferred over a1 with 0.3.\n\n"
        "Another example:\n"
        "- A value of 0.7 in position (Alt1, Alt3) means:\n"
        "\"The decision-maker prefers Alt1 to Alt3 with degree 0.7.\"\n\n"
        "Now consider the following fuzzy preference matrices from 4 decision-makers:\n\n"
        f"RP1 = {rp1}\n"
        f"RP2 = {rp2}\n"
        f"RP3 = {rp3}\n"
        f"RP4 = {rp4}\n"
        "Your task is to:\n"
        "Identify the single best overall alternative (only one).\n"
        "IMPORTANT: Output exactly one sentence.\n"
        "\"The best alternative is Alternative X.\"\n"
        "If no decision-makers meet the 70% threshold, say: \"No decision-makers supported Alternative X at the required threshold.\"\n\n"
        "Now output your answer below, with no extra explanation:\n---\n"
    )
    return prompt

# ————— Función de generación con slicing por delimitador —————
def run_mistral(prompt):
    # Tokenizar y mover a dispositivo
    inputs = tokenizer(prompt, return_tensors="pt", truncation=True)
    inputs = {k: v.to(model.device) for k, v in inputs.items()}
    input_len = inputs["input_ids"].shape[-1]

    # Generación
    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            max_new_tokens=400,
            do_sample=True,
            temperature=0.7,
            top_p=0.9,
            pad_token_id=tokenizer.eos_token_id
        )

    # Quedarnos solo con la parte nueva y decodificar
    new_tokens = outputs[0, input_len:]
    raw = tokenizer.decode(new_tokens, skip_special_tokens=True)

    # Recortar todo antes del delimitador '---\n'
    answer = raw.split("---\n", 1)[-1].strip()
    return answer

# ————— Uso del script —————
if __name__ == "__main__":
    prompt = build_prompt(r"C:\Users\quesa\Desktop\UGR\proyectoSalerno\preferences.json")
    result = run_mistral(prompt)

    print(result)

    # 1) Extraer número de alternativa
    m = re.search(r"The best alternative is Alt(\d+)\.", result)
    alternativa = int(m.group(1)) if m else None

    # 3) Volcar a JSON
    data = {
        "alternativa": alternativa
    }
    with open(r"C:\Users\quesa\Desktop\UGR\proyectoSalerno\Resultado.json", "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)