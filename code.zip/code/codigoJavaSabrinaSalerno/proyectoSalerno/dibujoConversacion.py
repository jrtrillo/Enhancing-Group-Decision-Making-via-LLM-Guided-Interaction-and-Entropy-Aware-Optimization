import matplotlib.pyplot as plt

# Función para leer valores desde un archivo txt
def leer_valores(archivo):
    with open(archivo, "r") as f:
        return [float(line.strip()) for line in f if line.strip()]

# Leer los dos conjuntos de valores
valores1 = leer_valores("converExperto.txt")
# Leer los dos conjuntos de valores
valores2 = leer_valores("converExperto2.txt")

# Graficar ambos conjuntos
plt.plot(valores1, marker='*', label="Flexible Expert")
plt.plot(valores2, marker='s', label="Rude Expert")


plt.title("Results")
plt.xlabel("Rounds of decision")
plt.ylabel("Consistency Level")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

