from fastapi import FastAPI
from pydantic import BaseModel
from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline
from huggingface_hub import login
import torch
import os

# Lee el token de Hugging Face desde variable de entorno
HF_TOKEN = "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"

if not HF_TOKEN:
    raise ValueError("Define la variable de entorno HUGGINGFACE_TOKEN con tu token de HF")

# Autentica en Hugging Face
login(HF_TOKEN)

# Modelo gated; asegúrate de haber aceptado la licencia en HF
MODEL_ID = "mistralai/Mistral-7B-Instruct-v0.1"

print("Loading tokenizer...")
tokenizer = AutoTokenizer.from_pretrained(MODEL_ID, use_auth_token=HF_TOKEN)

print("Loading model...")
dtype = torch.float16 if torch.cuda.is_available() else torch.float32
model = AutoModelForCausalLM.from_pretrained(
    MODEL_ID,
    use_auth_token=HF_TOKEN,
    torch_dtype=dtype,
    device_map="auto" if torch.cuda.is_available() else None
)

print("Creating pipeline...")
pipe = pipeline("text-generation", model=model, tokenizer=tokenizer)

# Ruta al fichero de preferencias (ajústala si es necesario)
PREFERENCES_PATH = r"C:\Users\quesa\Desktop\UGR\proyectoSalerno\preferences.txt"

app = FastAPI()

@app.post("/generate")
def generate():
    # Construye el prompt leyendo el fichero
    with open(PREFERENCES_PATH, "r", encoding="utf-8") as f:
        preferences = f.read()
    if not preferences.strip():
        print("Warning: preferences.txt está vacío")

    prompt = (
        "You are an AI that analyzes expert preferences.\n"
        "Given the following pairwise comparisons from different experts, "
        "determine which alternative is the best overall and which expert prefer that alternative:\n\n"
        "IMPORTANT: You should note that users prefer an alternative if they have a 60% or more "
        f"{preferences}\n\n"
        "Your answer must start with: 'The best alternative is Alternative X'\n"
        "Then provide a second sentence listing the experts who chose that alternative in this exact format:\n"
        "'The experts who decided on Alternative X are Expert Y and Expert Z.'\n"
    )

    # Genera la respuesta
    output = pipe(
        prompt,
        max_new_tokens=400,
        do_sample=True,
        temperature=0.7,
        top_p=0.9,
        return_full_text=False
    )
    generated = output[0]["generated_text"]
    return {"generated_text": generated}