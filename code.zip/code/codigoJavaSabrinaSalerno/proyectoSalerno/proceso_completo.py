from transformers import AutoTokenizer, AutoModelForCausalLM
from huggingface_hub import login
import torch
import re

# Autenticación en Hugging Face
login("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")

# Configuración del modelo
model_id = "tiiuae/falcon-7b"
tokenizer = AutoTokenizer.from_pretrained(model_id, token="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")
# model = AutoModelForCausalLM.from_pretrained(
#     model_id,
#     token="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",
#     torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
#     device_map="auto"
# )

device = "cuda" if torch.cuda.is_available() else "cpu"
model = AutoModelForCausalLM.from_pretrained(
    model_id,
    token="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",
    torch_dtype=torch.float16 if device == "cuda" else torch.float32,
    device_map={"": device}  # explicit device map
)

# === FASE 1: Prompt y ejecución ===
def build_prompt(file_path):
    with open(file_path, "r") as f:
        preferences = f.read()
    prompt = (
        "You are an AI assistant.\n"
        "Analyze the expert pairwise comparisons below and determine the best overall alternative.\n\n"
        "Important:\n"
        "- A preference is only valid if all the alternatives are chosen with more than 50% over the other.\n"
        "Based on valid preferences only, determine which alternative is the best overall\n"
        "Also, specify which experts support that alternative.\n\n"
        "Your answer must begin with: 'The best alternative is Alternative X.'\n"
        "'Experts in favor of Alternative X: Expert 1, Expert 3'"
    )

    return prompt, preferences

def run_mistral(prompt):
    print("Prompt length:", len(prompt))
    inputs = tokenizer(prompt, return_tensors="pt", truncation=True)
    inputs = {k: v.to(model.device) for k, v in inputs.items()}

    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            max_new_tokens=400,
            do_sample=True,
            temperature=0.7,
            top_p=0.9,
            pad_token_id=tokenizer.eos_token_id
        )

    result = tokenizer.decode(outputs[0], skip_special_tokens=True)
    return result

# === FASE 2: Procesamiento del resultado ===
def extract_global_decision(response):
    match = re.search(r"The best alternative is Alternative (\d)", response)
    return match.group(1) if match else None


def extract_all_experts_from_preferences(text):
    return sorted(set(re.findall(r"Expert \d+", text)))

def find_dissenting_experts(all_experts, supporting_experts):
    print("Los expertos son:", all_experts, "Los que apoyan son", supporting_experts)
    return [e for e in all_experts if e not in supporting_experts]

def generate_persuasion_message(expert, alt):
    return (
        f"{expert}, although you preferred a different alternative, most experts support Alternative {alt}.\n"
        f"This decision reflects consistent wins across evaluations.\n"
        f"Would you consider rethinking your choice in light of this consensus?\n"
    )


prompt, preferences_text = build_prompt("preferences.txt")
result = run_mistral(prompt)

print("\n=== Mistral Response ===\n")
print(result)

if not result.strip():
    print("⚠️ No response generated. Please check your prompt or system resources.")
    exit()

global_alt = extract_global_decision(result)

def extract_supporting_experts(response, global_alt):
    pattern = rf"Experts in favor of Alternative {global_alt}:\s*(.+)"
    match = re.search(pattern, response)
    if match:
        return [e.strip().rstrip(".") for e in match.group(1).split(",")]
    return []



supporting_experts = extract_supporting_experts(result, global_alt)
supporting_experts

all_experts = extract_all_experts_from_preferences(preferences_text)
dissenting_experts = find_dissenting_experts(all_experts, supporting_experts)
print(dissenting_experts)
print("\n=== Global Decision ===")
if global_alt:
    print(f"The best alternative is Alternative {global_alt}")
    print(f"\n=== Persuasive Messages ===\n")
    for expert in dissenting_experts:
        print(generate_persuasion_message(expert, global_alt))
else:
    print("⚠️ Could not determine the global best alternative from the model's response.")


