import matplotlib.pyplot as plt

def graficar_subplots_por_metodo(rondas, aceptacion_dict, gratitud_dict, titulo='Consistency-Satisfaction Study'):
    """
    Genera subplots separados para cada método, mostrando aceptación y gratitud, cada uno con colores diferentes.
    """
    metodos = list(aceptacion_dict.keys())
    fig, axes = plt.subplots(2, 2, figsize=(14, 8), sharex=True, sharey=True)
    axes = axes.flatten()

    # Paleta de colores oscuros (consistency) y claros (satisfaction)
    colores = [
        ('tab:blue', '#a6c8ff'),     # azul y azul claro
        ('tab:green', '#a8e6a3'),    # verde y verde claro
        ('tab:red', '#ffb3b3'),      # rojo y rojo claro
        ('tab:purple', '#dabfff')    # morado y morado claro
    ]

    for i, metodo in enumerate(metodos):
        ax = axes[i]
        color_consist, color_grat = colores[i]
        rondas_acept = rondas[:len(aceptacion_dict[metodo])]
        rondas_grat = rondas[:len(gratitud_dict[metodo])]

        ax.plot(rondas_acept, aceptacion_dict[metodo], marker='o', color=color_consist, label='Consistency')
        ax.plot(rondas_grat, gratitud_dict[metodo], linestyle='--', marker='x', color=color_grat, label='Satisfaction')

        ax.set_title(metodo)
        ax.set_ylim(0, 1.1)
        ax.set_xlabel('Round')
        ax.set_ylabel('Level')
        ax.legend(loc='lower right')

    plt.suptitle(titulo, fontsize=16)
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.show()


# Tus datos reales
rondas = [1, 2, 3, 4, 5]

aceptacion = {
    'Mean Value (μ = 0.5)': [0.8, 0.78, 0.8356],
    'Random Values': [0.67, 0.7, 0.794, 0.8117, 0.8117],
    'LLM (Mathematical)': [0.712, 0.7944, 0.8104, 0.8265, 0.8351],
    'LLM (Human-like reasoning)': [0.78, 0.81, 0.8314, 0.8501]
}

gratitud = {
    'Mean Value (μ = 0.5)': [0.7, 0.5, 0.3],
    'Random Values': [0.5, 0.6, 0.4, 0.4, 0.35],
    'LLM (Mathematical)': [0.7, 0.7, 0.8, 0.75, 0.75],
    'LLM (Human-like reasoning)': [0.7, 0.8, 0.85, 0.95]
}

# Ejecutar
graficar_subplots_por_metodo(rondas, aceptacion, gratitud)
