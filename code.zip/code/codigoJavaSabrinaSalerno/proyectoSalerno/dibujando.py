import matplotlib.pyplot as plt

# Función para leer valores desde un archivo txt
def leer_valores(archivo):
    with open(archivo, "r") as f:
        return [float(line.strip()) for line in f if line.strip()]

# Leer los dos conjuntos de valores
valores1 = leer_valores("valores1.txt")
valores2 = leer_valores("valores2.txt")
valores3 = leer_valores("valores3.txt")
valores4 = leer_valores("valores4.txt")
valores5 = leer_valores("valores5.txt")
valores6 = leer_valores("valores6.txt")
valores7 = leer_valores("valores7.txt")
valores8 = leer_valores("valores8.txt")

# Graficar ambos conjuntos
# plt.plot(valores1, marker='x', label="0.5*Consensus + 0.5*Consistency")
plt.plot(valores2, marker='o', label="Only Consensus")
# plt.plot(valores3, marker='x', label="0.5*Consensus + 0.5*Entropy")
# plt.plot(valores4, marker='*', label="Consensus^2 / (1+Entropy)")
plt.plot(valores5, marker='s', label="Linear Combination Variant")
plt.plot(valores6, marker='v', label="Nonlinear Entropy Penalty Formulation")
plt.plot(valores7, marker='D', label="Hybrid Nonlinear Variant")
# plt.plot(valores8, marker='^', label="0.7*Consensus + 0.3*Entropy")

plt.title("Results")
plt.xlabel("Rounds of decision")
plt.ylabel("Consensus Level")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

